import AImathPPhi2Clean.PeriodicHMinusThreeWeakLimitMarginal
import AImathPPhi2Clean.PeriodicFS4DProbeMoment
import AImathPPhi2Clean.Periodic3DGaussianWeakLimit
import AImathPPhi2Clean.Periodic3DGaussianFourierMarginals

#check @Pphi2Clean.Continuum.periodicHMinusThree_fixedVolume_weak_limit_exists_with_expected_cylinders
#print axioms Pphi2Clean.Continuum.periodicHMinusThree_fixedVolume_weak_limit_exists_with_expected_cylinders
#check @Pphi2Clean.Continuum.fs4PeriodicFixedVolume_weak_tendsto_free
#print axioms Pphi2Clean.Continuum.fs4PeriodicFixedVolume_weak_tendsto_free
#check @Pphi2Clean.Continuum.periodic3DFixedVolume_weak_tendsto_gaussianTarget
#print axioms Pphi2Clean.Continuum.periodic3DFixedVolume_weak_tendsto_gaussianTarget

example (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    ∃ μfree : MeasureTheory.ProbabilityMeasure
      Pphi2Clean.Continuum.PeriodicHMinusThreeCompletion,
      Pphi2Clean.Continuum.periodicHMinusThreeFixedVolumeFreeFieldWeakLimit
        L mass hL hmass μfree := by
  obtain ⟨μ, hμ, _⟩ :=
    Pphi2Clean.Continuum.periodicHMinusThree_fixedVolume_weak_limit_exists_with_expected_cylinders
      L mass hL hmass
  exact ⟨μ, hμ⟩

example (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    Filter.Tendsto
      (Pphi2Clean.Continuum.fs4PeriodicFixedVolumeProbabilityMeasure L mass hL hmass)
      Filter.atTop
      (nhds (Pphi2Clean.Continuum.fs4GaussianCarrierProbabilityMeasure L mass)) :=
  Pphi2Clean.Continuum.fs4PeriodicFixedVolume_weak_tendsto_free L mass hL hmass

example (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    Filter.Tendsto
      (Pphi2Clean.Continuum.periodic3DFixedVolumeProbabilityMeasure L mass hL hmass)
      Filter.atTop
      (nhds (Pphi2Clean.Continuum.periodic3DGaussianTargetProbabilityMeasure L mass)) :=
  Pphi2Clean.Continuum.periodic3DFixedVolume_weak_tendsto_gaussianTarget
    L mass hL hmass
