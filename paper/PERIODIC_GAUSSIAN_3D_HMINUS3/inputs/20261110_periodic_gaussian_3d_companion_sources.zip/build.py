#!/usr/bin/env python3
"""Build the companion manuscript with the local Tectonic installation."""
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    tectonic = os.environ.get('TECTONIC') or shutil.which('tectonic')
    fallback = Path(r'D:\Anaconda\envs\latex\Library\bin\tectonic.exe')
    if not tectonic and fallback.is_file():
        tectonic = str(fallback)
    if not tectonic:
        print('Missing Tectonic; set TECTONIC or add it to PATH.', file=sys.stderr)
        return 2
    env = dict(os.environ)
    cache = Path(env.get('TECTONIC_CACHE_DIR', ROOT / '.texcache'))
    seed = ROOT.parent / 'PERIODIC_GAUSSIAN_DIMENSION_BRIDGE' / '.texcache'
    if not cache.exists() and seed.exists():
        shutil.copytree(seed, cache)
    env['TECTONIC_CACHE_DIR'] = str(cache)
    env['SOURCE_DATE_EPOCH'] = '1793664000'
    output = ROOT / 'build'
    output.mkdir(exist_ok=True)
    for path in output.glob('main.*'):
        path.unlink()
    precheck = subprocess.run([sys.executable, 'audit/audit.py', '--source-only'], cwd=ROOT)
    if precheck.returncode:
        return precheck.returncode
    result = subprocess.run([tectonic, '--keep-logs', '--outdir', str(output), 'main.tex'],
                            cwd=ROOT, env=env)
    pdf = output / 'main.pdf'
    if result.returncode or not pdf.is_file():
        return 1
    log = (output / 'main.log').read_text(encoding='utf-8')
    if re.search(r'Overfull|undefined|Missing character', log, re.I):
        print('Tectonic reported a layout, reference, or glyph warning.', file=sys.stderr)
        return 1
    postcheck = subprocess.run([sys.executable, 'audit/audit.py', '--pdf', str(pdf),
                                '--report', 'audit/result.json'], cwd=ROOT)
    if postcheck.returncode:
        return postcheck.returncode
    shutil.copy2(pdf, ROOT / 'periodic_gaussian_3d_companion.pdf')
    print('BUILD OK: periodic_gaussian_3d_companion.pdf')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
