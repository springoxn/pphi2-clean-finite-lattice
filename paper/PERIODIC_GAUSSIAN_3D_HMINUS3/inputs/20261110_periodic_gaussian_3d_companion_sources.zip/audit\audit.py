#!/usr/bin/env python3
"""Source, Lean-contract, CAS-scale, and PDF checks for this manuscript."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def source_checks():
    files = [ROOT / 'main.tex', ROOT / 'bibliography.tex', *sorted((ROOT / 'sections').glob('*.tex'))]
    require(len(files) == 9, 'unexpected TeX source coverage')
    text = '\n'.join(path.read_text(encoding='utf-8') for path in files)
    for anchor in (
        'Fixed-volume raw-lift limit in dimension $d$',
        'periodic3DFixedVolume_weak_tendsto_gaussianTarget',
        'periodicHMinusThree_fixedVolume_weak_limit_exists_with_expected_cylinders',
        'fs4PeriodicFixedVolume_weak_tendsto_free',
        'not a Lean axiom', 'no single arbitrary-dimensional Lean declaration',
        'H^{-3}', 'H^{-4}', 'Nyquist', 'fourth-frequency-zero',
    ):
        require(anchor.lower() in text.lower(), 'missing manuscript anchor: ' + anchor)
    for env in ('equation', 'align', 'table', 'theorem', 'proof', 'lemma', 'proposition', 'enumerate'):
        require(text.count('\\begin{' + env + '}') == text.count('\\end{' + env + '}'),
                'unbalanced LaTeX environment: ' + env)
    labels = re.findall(r'\\label\{([^}]+)\}', text)
    require(len(labels) == len(set(labels)), 'duplicate LaTeX labels')
    for key in re.findall(r'\\(?:eqref|ref)\{([^}]+)\}', text):
        require(key in labels, 'undefined reference: ' + key)
    bibliography = set(re.findall(r'\\bibitem\{([^}]+)\}', text))
    for group in re.findall(r'\\cite\{([^}]+)\}', text):
        require(set(group.split(',')) <= bibliography, 'undefined citation: ' + group)
    contract = json.loads((ROOT / 'audit/three_dimensional_contract.json').read_text(encoding='utf-8'))
    query_path = ROOT / 'audit/three_dimensional_contract.lean'
    log_path = ROOT / 'audit/three_dimensional_contract.log'
    require(hashlib.sha256(query_path.read_bytes()).hexdigest() == contract['query_sha256'], 'Lean query hash mismatch')
    require(hashlib.sha256(log_path.read_bytes()).hexdigest() == contract['output_sha256'], 'Lean output hash mismatch')
    census_path = ROOT / 'audit/source_census.log'
    manifest_path = ROOT / 'audit/source_manifest.log'
    require(hashlib.sha256(census_path.read_bytes()).hexdigest() == contract['source_census_log_sha256'],
            'source census log hash mismatch')
    require(hashlib.sha256(manifest_path.read_bytes()).hexdigest() == contract['manifest_log_sha256'],
            'source manifest log hash mismatch')
    require(contract['exit_code'] == 0, 'Lean query did not exit successfully')
    census_log = census_path.read_text(encoding='utf-8')
    require(re.search(r'whole package\s+116 modules, 1308 declarations \(theorem-level 939\)', census_log),
            'source census does not match the registered counts')
    require('other current sources   114 modules, 21739 lines' in census_log and
            'current extension files 2 modules, 282 lines' in census_log,
            'module line count inputs do not match')
    require('sorry occurrences       0' in census_log and 'axiom declarations      0' in census_log and
            'PASS counts' in census_log, 'source cleanliness check missing or failed')
    manifest_log = manifest_path.read_text(encoding='utf-8')
    require('PASS manifest     505 files verified against MANIFEST.sha256' in manifest_log,
            'source manifest check missing or failed')
    log = log_path.read_text(encoding='utf-8')
    names = (
        'periodicHMinusThree_fixedVolume_weak_limit_exists_with_expected_cylinders',
        'fs4PeriodicFixedVolume_weak_tendsto_free',
        'periodic3DFixedVolume_weak_tendsto_gaussianTarget',
    )
    allowed = {'propext', 'Classical.choice', 'Quot.sound'}
    for name in names:
        full = 'Pphi2Clean.Continuum.' + name
        require(re.search(re.escape(full) + r'\s*:', log) is not None, 'missing Lean signature: ' + name)
        match = re.search("'" + re.escape(full) + r"' depends on axioms:\s*\[([^]]*)\]", log)
        require(match is not None, 'missing axiom output: ' + name)
        actual = {item.strip() for item in match.group(1).split(',')}
        require(actual == allowed, 'unexpected axiom footprint: ' + name)
    require(not re.search(r'error:|sorryAx|customAssumption', log), 'Lean transcript contains failure marker')
    return files, contract


def scale_checks():
    import sympy as sp
    a, N, L, m = sp.symbols('a N L m', positive=True)
    for d in (1, 2, 3, 4, 5):
        prefactor = a**(2*d) * a**(-d) * N**(-d) * N**(2*d)
        require(sp.simplify(prefactor.subs(a, L/N) - L**d) == 0, 'physical-volume prefactor')
    target_scale = sp.simplify((L**(-sp.Rational(1, 2)))**2 * L**4 - L**3)
    require(target_scale == 0, '4D-to-3D target scale')
    return {'dimension_values_checked': [1, 2, 3, 4, 5], 'target_slice_scale': 'L^3'}


def pdf_checks(pdf):
    import fitz
    with fitz.open(pdf) as doc:
        require(len(doc) >= 6, 'unexpectedly short PDF')
        text = ' '.join(' '.join(page.get_text().split()) for page in doc)
        for phrase in ('dimension-uniform Fourier theorem', 'formal three-dimensional',
                       'Table 1.', 'Table 2.', 'Table 3.', 'Table 4.', 'Evidence ledger', 'References',
                       '22,021 lines', '1,308 declarations', '939 are theorem or lemma forms'):
            require(phrase.lower() in text.lower(), 'PDF missing expected content: ' + phrase)
        require('\ufffd' not in text, 'PDF contains replacement glyph')
        require(not re.search(r'\?\?|undefined', text, re.I), 'PDF contains unresolved reference text')
        for page in doc:
            require(len(page.get_text().strip()) > 30, 'blank or textless page')
            for block in page.get_text('dict')['blocks']:
                for line in block.get('lines', []):
                    for span in line['spans']:
                        x0, y0, x1, y1 = span['bbox']
                        require(x0 >= 30 and x1 <= page.rect.width - 30, 'text crosses horizontal margin')
                        require(y0 >= 18 and y1 <= page.rect.height - 18, 'text crosses vertical margin')
        return {'pages': len(doc), 'sha256': hashlib.sha256(pdf.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-only', action='store_true')
    parser.add_argument('--pdf', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    try:
        files, contract = source_checks()
        result = {
            'source_sha256': {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                              for path in files},
            'lean_contract': {'release_commit': contract['release_commit'],
                              'toolchain': contract['toolchain'],
                              'mathlib_rev': contract['mathlib_rev'],
                              'three_endpoints': contract['theorems'],
                              'axioms': contract['axioms'],
                              'only_foundational_axioms': True},
            'source_census': contract['source_census'],
            'source_manifest_files_verified': contract['manifest_files_verified'],
            'scale_checks': scale_checks(),
        }
        if not args.source_only:
            result['artifact'] = pdf_checks(args.pdf or ROOT / 'periodic_gaussian_3d_companion.pdf')
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(result, indent=2))
        print('PASS manuscript sources, Lean transcript, normalization checks and requested PDF checks')
        return 0
    except Exception as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
