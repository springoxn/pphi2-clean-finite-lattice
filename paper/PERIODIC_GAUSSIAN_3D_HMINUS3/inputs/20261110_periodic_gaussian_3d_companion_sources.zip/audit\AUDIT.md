# Manuscript audit record

Audit date: 2026-11-10. This file records both successful checks and the issues found while producing the companion manuscript.

## Findings and repairs

- The first source audit found that the 2D and 4D public theorem names were not written explicitly in the comparison section. They were added and are now checked against the recorded joint Lean transcript.
- The first PDF pass found an unbreakable display line and an orphaned short paragraph before the bibliography. The proof-flow display was reformatted, table labels were shortened, and the forced page break before the references was removed. The final PDF has no overfull boxes; ordinary underfull-box warnings remain.
- The first release-manifest check found the temporary Lean query inside the pinned source tree, where it was correctly reported as an unlisted file. The query was moved to `/tmp`, replayed there against the same release, and removed from the source tree. The manifest check then passed.
- A combined `verify.py --all` run exceeded the SSH-MCP 60-second command limit and was terminated. No claim of that aggregate run passing is made. Its relevant checks were instead run separately: manifest verification, source census, targeted four-module Lean build, and the joint three-endpoint Lean contract all passed.
- The source census wording was shortened, and the PDF audit initially caught two brittle text assumptions: the old “module lines” phrase and TeX hyphenation of the theorem/lemma count. The visible label is now break-safe and the PDF check uses stable rendered text; the full build/audit passes.
- Tectonic emitted a local Fontconfig configuration diagnostic and underfull-box warnings. The PDF was still produced; visual inspection and the PDF audit found no missing pages, clipped text, unresolved references, or overfull lines.

No mathematical claim was refuted by this audit; the identified defects concerned manuscript layout, audit anchors, and temporary evidence-file placement.

## Final evidence

- The contract is bound to source commit `b0be3960210d5c638513de9995850e318b1a5b4d`, Lean `v4.34.0-rc2`, and Mathlib revision `852d20a84581aeba8527bd01d0be361d8c0e71c0`.
- The joint Lean query checks the signatures and types of the 2D, 3D, and 4D endpoints. Each `#print axioms` result is exactly `[propext, Classical.choice, Quot.sound]`; no `sorryAx` appears in these theorem footprints.
- The pinned package census reports 116 Lean modules, 22,021 module lines, 1,308 declaration forms including 939 theorem/lemma declarations, zero source `sorry` occurrences, and zero declared `axiom` constants. These are package-wide counts, not 3D-only proof statistics.
- The final PDF audit checks source anchors, references, table captions, PDF text and page bounds, and symbolic volume/target-slice normalizations. The final rendered PDF is nine pages.

## Claims left qualified

The arbitrary-dimensional result is an analytic theorem proved in the paper, not a Lean axiom and not a generic Lean theorem. The 3D Lean endpoint is on `H^{-4}`; this article does not claim a Lean proof of its sharper `H^{-3}` paper specialization. The 4D Gaussian carrier is used to construct the 3D target, while the finite sources and covariance identification remain three-dimensional. The existing 2D/4D article and its deliverables were not modified.
