# A three-dimensional periodic Gaussian limit

This is a new companion manuscript centered on the Lean-verified 3D fixed-volume periodic Gaussian raw-lift theorem. It is separate from, and does not overwrite, the 2D/4D dimensional-bridge article published on 2026-11-09.

The article contains the dimension-uniform analytic theorem and its proof, then distinguishes that paper result from the concrete Lean endpoints: 2D on `H^-3`, 3D on `H^-4`, and 4D on `H^-4`. In particular, it does not claim an arbitrary-dimensional Lean theorem. The phrase “n-dimensional axiom” is treated as the general-dimensional paper theorem; it is not a Lean axiom.

## Build and audit

From this directory, run:

```powershell
python audit/audit.py --source-only
python build.py
python audit/audit.py --pdf periodic_gaussian_3d_companion.pdf
```

The executed Lean contract, release commit, and theorem axiom footprints are stored under `audit/`. The 3D Lean source of truth remains the public source snapshot linked in the bibliography and the canonical server project.
