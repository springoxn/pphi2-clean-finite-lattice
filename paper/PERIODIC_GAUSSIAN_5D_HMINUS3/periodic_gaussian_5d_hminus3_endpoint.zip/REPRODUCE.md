# Five-dimensional actual-source H-minus-three endpoint

Use Lean leanprover/lean4:v4.34.0-rc2. Mathlib and inherited packages are locked.
Run from this extracted directory:

```sh
lake exe cache get
python REPRODUCE.py
```

REPRODUCE.py verifies all packaged source/configuration hashes, builds the final module, and executes the typed endpoint/axiom contract.
The complete project sources are included; no prior 3D source is modified.
The H-minus-three carrier uses (1+supnorm(k))^(-6) as Fourier weight.
The main theorem is full-sequence weak convergence of the physical a^5 raw atomic lifts at N=n+1 and a=L/N.
The target is constructed from actual source laws and uniquely identified by all finite Fourier-family 5D resolvent Gaussian marginals.
No infinite-dimensional IsGaussian predicate or external distribution-space isomorphism is asserted.
Audit transcripts record the original successful pinned build and standard-only axiom footprints.
