import AImathPPhi2Clean.Periodic5DProbeMoment

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice

/-- The actual a^5 raw atomic source, evaluated at complex Fourier modes. -/
def periodic5DRawAtomicLift (N : ℕ) [NeZero N] (a L : ℝ) (hL : 0 < L) :
    FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)) →
      (Fin 5 → ℤ) → ℂ :=
  fun ω k => periodic5DComplexFourierProbe L hL k
    (latticeEmbedLift (physicalTestEval 5 N a) ω)

theorem periodic5DRawAtomicLift_integral_norm_sq_eq_probeMoment
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hL : 0 < L) (k : Fin 5 → ℤ) :
    ∫ ω, ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
      finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass) =
        periodic5DComplexFourierProbeMoment N a mass L ha hmass hL k := by
  let μ := physicalGJMeasure 5 N a mass ha hmass
  have hcosLaw := physicalGJMeasure_eval_hasGaussianLaw 5 N a mass ha hmass
    (periodicCosineTest 5 L k hL)
  have hsinLaw := physicalGJMeasure_eval_hasGaussianLaw 5 N a mass ha hmass
    (periodicSineTest 5 L k hL)
  have hcosInt : Integrable (fun ω => (ω (periodicCosineTest 5 L k hL)) ^ 2) μ :=
    hcosLaw.memLp_two.integrable_sq
  have hsinInt : Integrable (fun ω => (ω (periodicSineTest 5 L k hL)) ^ 2) μ :=
    hsinLaw.memLp_two.integrable_sq
  have hprobeI : Integrable (fun ω => ‖periodic5DComplexFourierProbe L hL k ω‖ ^ 2) μ := by
    apply (hcosInt.add hsinInt).congr
    filter_upwards [] with ω
    exact (periodic5DComplexFourierProbe_norm_sq L hL k ω).symm
  have hmap := integral_map
    (latticeEmbedLift_measurable (physicalTestEval 5 N a)).aemeasurable
    hprobeI.aestronglyMeasurable
  exact hmap.symm

theorem periodic5DRawAtomicLift_integral_norm_sq_le
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) (k : Fin 5 → ℤ) :
    ∫ ω, ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
      finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass) ≤
        2 * (mass⁻¹ ^ 2 * L ^ 5) := by
  rw [periodic5DRawAtomicLift_integral_norm_sq_eq_probeMoment]
  exact periodic5DComplexFourierProbeMoment_le N a mass L ha hmass hvol hL k

end Pphi2Clean.Continuum
