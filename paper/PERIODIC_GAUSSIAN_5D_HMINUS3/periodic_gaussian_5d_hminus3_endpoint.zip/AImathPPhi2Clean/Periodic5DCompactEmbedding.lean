import AImathPPhi2Clean.Periodic5DWeightedCarrier

noncomputable section
namespace Pphi2Clean.Continuum

/-- Outside a finite frequency box the H^-3/H^(-11/4) weight ratio is small. -/
theorem periodic5D_weight_ratio_tendsto_zero :
    ∀ δ : ℝ, 0 < δ → ∃ K : Finset Periodic5DIndex,
      ∀ k, k ∉ K → periodic5DSobolevWeight 3 k ≤
        δ * periodic5DSobolevWeight (11 / 4) k := by
  intro δ hδ
  let T : ℝ := δ⁻¹ ^ 2 + 1
  have hT : 0 < T := by dsimp [T]; positivity
  let box : Set Periodic5DIndex := Set.univ.pi (fun _ =>
    Set.Icc (-(⌈T⌉₊ : ℤ)) (⌈T⌉₊ : ℤ))
  have hbox : box.Finite := Set.Finite.pi (fun _ => Set.finite_Icc _ _)
  refine ⟨hbox.toFinset, ?_⟩
  intro k hk
  have hnorm : T < ‖k‖ := by
    by_contra hnot
    have hle : ‖k‖ ≤ T := le_of_not_gt hnot
    apply hk
    apply hbox.mem_toFinset.mpr
    change ∀ i ∈ (Set.univ : Set (Fin 5)), k i ∈ Set.Icc _ _
    intro i hi
    have hcoord : |(k i : ℝ)| ≤ (⌈T⌉₊ : ℝ) := by
      calc
        |(k i : ℝ)| = ‖k i‖ := by simp [Int.norm_eq_abs, Int.cast_abs]
        _ ≤ ‖k‖ := norm_le_pi_norm k i
        _ ≤ T := hle
        _ ≤ ⌈T⌉₊ := Nat.le_ceil T
    have hiabs : |k i| ≤ (⌈T⌉₊ : ℤ) := by exact_mod_cast hcoord
    exact abs_le.mp hiabs
  have hbase : 0 < 1 + ‖k‖ := by positivity
  have hsqrt : δ⁻¹ ≤ Real.sqrt (1 + ‖k‖) := by
    apply (Real.le_sqrt (inv_nonneg.mpr hδ.le) hbase.le).2
    dsimp [T] at hnorm
    linarith
  have hsmall : (1 + ‖k‖) ^ (-(1 / 2 : ℝ)) ≤ δ := by
    rw [Real.rpow_neg hbase.le, ← Real.sqrt_eq_rpow]
    calc
      (Real.sqrt (1 + ‖k‖))⁻¹ ≤ (δ⁻¹)⁻¹ :=
        inv_anti₀ (inv_pos.mpr hδ) hsqrt
      _ = δ := inv_inv δ
  have hweight : periodic5DSobolevWeight 3 k =
      periodic5DSobolevWeight (11 / 4) k * (1 + ‖k‖) ^ (-(1 / 2 : ℝ)) := by
    unfold periodic5DSobolevWeight
    rw [← Real.rpow_add hbase]
    norm_num
  rw [hweight]
  calc
    _ ≤ periodic5DSobolevWeight (11 / 4) k * δ :=
      mul_le_mul_of_nonneg_left hsmall (periodic5DSobolevWeight_nonneg _ k)
    _ = _ := mul_comm _ _


abbrev Periodic5DHminusThreeCompletion := Periodic5DCompletion
abbrev periodic5DElevenQuartersCoefficientCarrier := periodic5DCarrier (11 / 4)
abbrev periodic5DHminusThreeCoefficientCarrier := periodic5DCarrier 3
abbrev periodic5DHminusThreeEmbeddingOfCoefficients := periodic5DEmbeddingOfCoefficients 3
abbrev periodic5DElevenQuartersNorm := periodic5DCarrierNorm (11 / 4)

theorem periodic5D_eleven_quarters_coefficients_in_hminus3 (c : Periodic5DIndex → ℂ)
    (hc : c ∈ periodic5DElevenQuartersCoefficientCarrier) : c ∈ periodic5DHminusThreeCoefficientCarrier := by
  exact Summable.of_nonneg_of_le
    (fun k => mul_nonneg (periodic5DSobolevWeight_nonneg 3 k) (sq_nonneg _))
    (fun k => mul_le_mul_of_nonneg_right (periodic5DSobolevWeight_antitone (by norm_num : (11 / 4 : ℝ) ≤ 3) k) (sq_nonneg _)) hc
theorem periodic5D_hminus3_tail_sq_le_of_weight_ratio
    {c : Periodic5DIndex → ℂ} (K : Finset Periodic5DIndex) (δ : ℝ)
    (hδ : 0 ≤ δ)
    (hweight : ∀ k, k ∉ K → periodic5DSobolevWeight 3 k ≤ δ * periodic5DSobolevWeight (11 / 4) k)
    (hc : Summable (fun k : Periodic5DIndex => periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2)) :
    (∑' k, if k ∉ K then periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0) ≤
      δ * (∑' k, periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) := by
  have hmajor : Summable (fun k : Periodic5DIndex =>
      δ * (periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2)) := by
    simpa only [mul_assoc] using hc.mul_left δ
  have htail : Summable (fun k : Periodic5DIndex => if k ∉ K then
      periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0) := by
    refine Summable.of_nonneg_of_le
      (f := fun k : Periodic5DIndex => δ * (periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2))
      (g := fun k : Periodic5DIndex => if k ∉ K then
        periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0) ?_ ?_ hmajor
    · intro k
      by_cases hk : k ∈ K
      · simp [hk]
      · simp [hk]
        exact mul_nonneg (periodic5DSobolevWeight_nonneg 3 k) (sq_nonneg _)
    · intro k
      by_cases hk : k ∈ K
      · simp [hk]
        exact mul_nonneg hδ (mul_nonneg (periodic5DSobolevWeight_nonneg (11 / 4) k) (sq_nonneg _))
      · simp [hk]
        simpa [hk, mul_assoc] using
          (mul_le_mul_of_nonneg_right (hweight k hk) (sq_nonneg (‖c k‖)))
  calc
    (∑' k : Periodic5DIndex, if k ∉ K then
        periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0) ≤
        ∑' k, δ * (periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) := by
      exact htail.tsum_le_tsum (fun k => by
        by_cases hk : k ∈ K
        · simp [hk]
          exact mul_nonneg hδ (mul_nonneg (periodic5DSobolevWeight_nonneg (11 / 4) k) (sq_nonneg _))
        · simp [hk]
          simpa [hk, mul_assoc] using
            (mul_le_mul_of_nonneg_right (hweight k hk) (sq_nonneg (‖c k‖)))) hmajor
    _ = δ * (∑' k, periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) := by
      rw [tsum_mul_left]

theorem periodic5D_hminus3_uniform_tail_of_eleven_quarters_bound :
    ∀ R : ℝ, 0 ≤ R → ∀ ε : ℝ, 0 < ε →
      ∃ K : Finset Periodic5DIndex, ∀ c : Periodic5DIndex → ℂ,
        Summable (fun k => periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) →
        periodic5DElevenQuartersNorm c ≤ R →
        Real.sqrt (∑' k, if k ∉ K then
          periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0) < ε := by
  intro R hR ε hε
  let δ := (ε / (R + 1)) ^ 2
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨K, hK⟩ := periodic5D_weight_ratio_tendsto_zero δ hδ
  refine ⟨K, ?_⟩
  intro c hc hnorm
  have hnorm_sq :
      (∑' k : Periodic5DIndex, periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) ≤ R ^ 2 := by
    change Real.sqrt (∑' k : Periodic5DIndex,
      periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) ≤ R at hnorm
    exact (Real.sqrt_le_iff).mp hnorm |>.2
  have htail := periodic5D_hminus3_tail_sq_le_of_weight_ratio K δ hδ.le hK hc
  have htail_nonneg : 0 ≤ ∑' k : Periodic5DIndex, if k ∉ K then
      periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0 :=
    tsum_nonneg fun k => by
      by_cases hk : k ∉ K
      · simp [hk]
        exact mul_nonneg (periodic5DSobolevWeight_nonneg 3 k) (sq_nonneg ‖c k‖)
      · simp [hk]
  apply (Real.sqrt_lt htail_nonneg hε.le).2
  calc
    (∑' k : Periodic5DIndex, if k ∉ K then
        periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0) ≤
        δ * (∑' k : Periodic5DIndex,
          periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) := htail
    _ ≤ δ * R ^ 2 := mul_le_mul_of_nonneg_left hnorm_sq hδ.le
    _ < ε ^ 2 := by
      dsimp [δ]
      have hden : 0 < R + 1 := by linarith
      have hratio_nonneg : 0 ≤ R / (R + 1) := div_nonneg hR hden.le
      have hratio_lt : R / (R + 1) < 1 := (div_lt_one hden).2 (by linarith)
      have hratio_sq : (R / (R + 1)) ^ 2 < 1 := by
        have hsum_pos : 0 < 1 + R / (R + 1) := by linarith
        nlinarith [mul_pos (sub_pos.mpr hratio_lt) hsum_pos]
      have hcalc :
          (ε / (R + 1)) ^ 2 * R ^ 2 =
            ε ^ 2 * (R / (R + 1)) ^ 2 := by
        field_simp [ne_of_gt hden] <;> ring
      rw [hcalc]
      calc
        ε ^ 2 * (R / (R + 1)) ^ 2 < ε ^ 2 * 1 :=
          mul_lt_mul_of_pos_left hratio_sq (sq_pos_of_pos hε)
        _ = ε ^ 2 := by ring

def periodic5DHminusThreeFiniteProjection (K : Finset Periodic5DIndex)
    (z : {k // k ∈ K} → ℂ) : Periodic5DHminusThreeCompletion :=
  ∑ k : {k // k ∈ K}, lp.single (E := fun _ : Periodic5DIndex => ℂ)
    2 (k : Periodic5DIndex) (z k)

theorem periodic5DHminusThreeFiniteProjection_continuous (K : Finset Periodic5DIndex) :
    Continuous (periodic5DHminusThreeFiniteProjection K) := by
  apply continuous_finsetSum
  intro k hk
  exact (lp.singleContinuousAddMonoidHom
    (fun _ : Periodic5DIndex => ℂ) 2 (k : Periodic5DIndex)).continuous.comp
      (continuous_apply k)

theorem periodic5DHminusThreeFiniteProjection_boundedBall_compact
    (K : Finset Periodic5DIndex) (B : ℝ) :
    IsCompact (periodic5DHminusThreeFiniteProjection K ''
      {z : {k // k ∈ K} → ℂ | ∀ k, ‖z k‖ ≤ B}) := by
  have hpi : IsCompact {z : {k // k ∈ K} → ℂ | ∀ k, ‖z k‖ ≤ B} := by
    convert (isCompact_pi_infinite (fun _ : {k // k ∈ K} =>
      isCompact_closedBall (0 : ℂ) B)) using 1
    ext z
    simp [Metric.mem_closedBall, dist_eq_norm]
  exact hpi.image (periodic5DHminusThreeFiniteProjection_continuous K)


theorem periodic5DHminusThreeEmbedding_norm_eq_compact (c : Periodic5DIndex → ℂ)
    (hc : c ∈ periodic5DHminusThreeCoefficientCarrier) :
    ‖periodic5DHminusThreeEmbeddingOfCoefficients c hc‖ = periodic5DHminusThreeNorm c :=
  periodic5DHminusThreeEmbedding_norm_eq c hc

theorem periodic5DHminusThreeEmbedding_norm_le_three_compact (c : Periodic5DIndex → ℂ)
    (hc : c ∈ periodic5DElevenQuartersCoefficientCarrier) :
    ‖periodic5DHminusThreeEmbeddingOfCoefficients c
      (periodic5D_eleven_quarters_coefficients_in_hminus3 c hc)‖ ≤ periodic5DElevenQuartersNorm c := by
  have hc4 := periodic5D_eleven_quarters_coefficients_in_hminus3 c hc
  have hsum4 : Summable (fun k => periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2) := hc4
  have hnn4 : ∀ k : Periodic5DIndex, 0 ≤ periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 :=
    fun k => mul_nonneg (periodic5DSobolevWeight_nonneg 3 k) (sq_nonneg _)
  have hnn3 : ∀ k : Periodic5DIndex, 0 ≤ periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2 :=
    fun k => mul_nonneg (periodic5DSobolevWeight_nonneg (11 / 4) k) (sq_nonneg _)
  have hle : ∀ k : Periodic5DIndex,
      periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 ≤ periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2 :=
    fun k => mul_le_mul_of_nonneg_right (periodic5DSobolevWeight_antitone (by norm_num : (11 / 4 : ℝ) ≤ 3) k) (sq_nonneg _)
  have hE : (∑' k : Periodic5DIndex,
      ENNReal.ofReal (periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2)) ≤
      ∑' k : Periodic5DIndex,
        ENNReal.ofReal (periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2) :=
    ENNReal.tsum_le_tsum (fun k => ENNReal.ofReal_le_ofReal (hle k))
  rw [← ENNReal.ofReal_tsum_of_nonneg hnn4 hsum4,
      ← ENNReal.ofReal_tsum_of_nonneg hnn3 hc] at hE
  have hreal :
      (∑' k : Periodic5DIndex, periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2) ≤
        ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11 / 4) k * ‖c k‖ ^ 2 :=
    (ENNReal.ofReal_le_ofReal_iff (tsum_nonneg hnn3)).mp hE
  rw [periodic5DHminusThreeEmbedding_norm_eq_compact c hc4]
  unfold periodic5DHminusThreeNorm periodic5DElevenQuartersNorm
  exact Real.sqrt_le_sqrt hreal

theorem periodic5D_lp_fourier_projection_error_sq_eq_tail
    (K : Finset Periodic5DIndex) (x : Periodic5DHminusThreeCompletion) :
    ‖x - periodic5DHminusThreeFiniteProjection K (fun k => x (k : Periodic5DIndex))‖ ^ (2 : ℝ) =
      ∑' k : Periodic5DIndex, if k ∉ K then ‖x k‖ ^ 2 else 0 := by
  let hp : 0 < (2 : ENNReal).toReal := by norm_num
  have hsum : Summable (fun k : Periodic5DIndex => ‖x k‖ ^ (2 : ℝ)) :=
    (lp.memℓp x).summable hp
  have hsplit := hsum.sum_add_tsum_compl (s := K)
  have hnormx := lp.norm_rpow_eq_tsum hp x
  have hnormdiff := lp.norm_compl_sum_single hp x K
  have htail :
      (∑' k : Periodic5DIndex, if k ∉ K then ‖x k‖ ^ 2 else 0) =
        ∑' j : {k : Periodic5DIndex // k ∈ (↑K : Set Periodic5DIndex)ᶜ}, ‖x j‖ ^ (2 : ℝ) := by
    calc
      (∑' k : Periodic5DIndex, if k ∉ K then ‖x k‖ ^ 2 else 0) =
          ∑' k : Periodic5DIndex, ((↑K : Set Periodic5DIndex)ᶜ).indicator
            (fun k => ‖x k‖ ^ 2) k := by
        congr 1
        funext k
        by_cases hk : k ∈ K <;> simp [Set.indicator, hk]
      _ = ∑' j : {k : Periodic5DIndex // k ∈ (↑K : Set Periodic5DIndex)ᶜ},
            ‖x j‖ ^ (2 : ℝ) := (tsum_subtype _ _).symm
  simp only [ENNReal.toReal_ofNat] at hnormx hnormdiff
  have hnormdiff' :
      ‖x - periodic5DHminusThreeFiniteProjection K (fun k => x (k : Periodic5DIndex))‖ ^ (2 : ℝ) =
        ‖x‖ ^ (2 : ℝ) - ∑ k ∈ K, ‖x k‖ ^ (2 : ℝ) := by
    simpa [periodic5DHminusThreeFiniteProjection] using hnormdiff
  calc
    ‖x - periodic5DHminusThreeFiniteProjection K (fun k => x (k : Periodic5DIndex))‖ ^ (2 : ℝ) =
        ‖x‖ ^ (2 : ℝ) - ∑ k ∈ K, ‖x k‖ ^ (2 : ℝ) := hnormdiff'
    _ = ∑' j : {k : Periodic5DIndex // k ∈ (↑K : Set Periodic5DIndex)ᶜ},
          ‖x j‖ ^ (2 : ℝ) := by
      rw [hnormx]
      linarith [hsplit]
    _ = ∑' k : Periodic5DIndex, if k ∉ K then ‖x k‖ ^ 2 else 0 := htail.symm

def periodic5DElevenQuartersBallInHminusThree (B : ℝ) : Set Periodic5DHminusThreeCompletion :=
  {x | ∃ c : Periodic5DIndex → ℂ, ∃ hc : c ∈ periodic5DElevenQuartersCoefficientCarrier,
    periodic5DElevenQuartersNorm c ≤ B ∧
      x = periodic5DHminusThreeEmbeddingOfCoefficients c
        (periodic5D_eleven_quarters_coefficients_in_hminus3 c hc)}

theorem periodic5DElevenQuartersBall_compact_approximation (B : ℝ) (hB : 0 ≤ B)
    (ε : ℝ) (hε : 0 < ε) :
    ∃ T : Set Periodic5DHminusThreeCompletion, IsCompact T ∧
      ∀ x ∈ periodic5DElevenQuartersBallInHminusThree B, ∃ y ∈ T, dist x y < ε := by
  let η := ε / 2
  have hη : 0 < η := by dsimp [η]; positivity
  obtain ⟨K, hK⟩ := periodic5D_hminus3_uniform_tail_of_eleven_quarters_bound B hB η hη
  let T := periodic5DHminusThreeFiniteProjection K ''
    {z : {k // k ∈ K} → ℂ | ∀ k, ‖z k‖ ≤ B}
  have hT : IsCompact T := periodic5DHminusThreeFiniteProjection_boundedBall_compact K B
  refine ⟨T, hT, ?_⟩
  intro x hx
  rcases hx with ⟨c, hc, hcB, rfl⟩
  let h4 := periodic5D_eleven_quarters_coefficients_in_hminus3 c hc
  let xh := periodic5DHminusThreeEmbeddingOfCoefficients c h4
  let z : {k // k ∈ K} → ℂ := fun k => xh (k : Periodic5DIndex)
  have hz : ∀ k, ‖z k‖ ≤ B := by
    intro k
    calc
      ‖z k‖ ≤ ‖xh‖ := lp.norm_apply_le_norm (by norm_num : (2 : ENNReal) ≠ 0) xh _
      _ = periodic5DHminusThreeNorm c := periodic5DHminusThreeEmbedding_norm_eq_compact c h4
      _ ≤ periodic5DElevenQuartersNorm c := by
        calc
          periodic5DHminusThreeNorm c = ‖periodic5DHminusThreeEmbeddingOfCoefficients c h4‖ :=
            (periodic5DHminusThreeEmbedding_norm_eq_compact c h4).symm
          _ ≤ periodic5DElevenQuartersNorm c := periodic5DHminusThreeEmbedding_norm_le_three_compact c hc
      _ ≤ B := hcB
  let y := periodic5DHminusThreeFiniteProjection K z
  refine ⟨y, ⟨z, hz, rfl⟩, ?_⟩
  have htail := hK c hc hcB
  let q : ℝ := ∑' k : Periodic5DIndex, if k ∉ K then
    periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2 else 0
  have hq : 0 ≤ q := by
    dsimp [q]
    apply tsum_nonneg
    intro k
    by_cases hk : k ∉ K
    · simp [hk]
      exact mul_nonneg (periodic5DSobolevWeight_nonneg 3 k) (sq_nonneg _)
    · simp [hk]
  have hqη : Real.sqrt q < η := by
    dsimp [q] at htail ⊢
    exact htail
  have herror_sq : ‖xh - y‖ ^ (2 : ℝ) = q := by
    rw [periodic5D_lp_fourier_projection_error_sq_eq_tail]
    dsimp [y, z, xh, q]
    apply tsum_congr
    intro k
    by_cases hk : k ∉ K
    · simp only [hk]
      change ‖periodic5DWeightedFourierCoefficients 3 c k‖ ^ 2 =
        periodic5DSobolevWeight 3 k * ‖c k‖ ^ 2
      have hw := periodic5DSobolevWeight_nonneg 3 k
      simp [periodic5DWeightedFourierCoefficients, Complex.norm_real,
        Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _)]
      nlinarith [Real.sq_sqrt hw]
    · simp [hk]
  have hnorm_eq : ‖xh - y‖ = Real.sqrt q := by
    calc
      ‖xh - y‖ = Real.sqrt (‖xh - y‖ ^ 2) := by
        rw [Real.sqrt_sq_eq_abs, abs_of_nonneg (norm_nonneg _)]
      _ = Real.sqrt q := by
        congr 1
        exact_mod_cast herror_sq
  dsimp [η] at hqη
  calc
    dist xh y = ‖xh - y‖ := dist_eq_norm xh y
    _ = Real.sqrt q := hnorm_eq
    _ < ε / 2 := hqη
    _ < ε := by linarith

theorem periodic5D_totallyBounded_of_compact_approximation
    {E : Type*} [PseudoMetricSpace E] {S : Set E}
    (happrox : ∀ ε : ℝ, 0 < ε → ∃ T : Set E,
      IsCompact T ∧ ∀ x ∈ S, ∃ y ∈ T, dist x y < ε) :
    TotallyBounded S := by
  rw [Metric.totallyBounded_iff]
  intro ε hε
  obtain ⟨T, hT, happroxT⟩ := happrox (ε / 2) (by positivity)
  obtain ⟨centers, hfinite, hcover⟩ :=
    (Metric.totallyBounded_iff.mp hT.totallyBounded) (ε / 2) (by positivity)
  refine ⟨centers, hfinite, ?_⟩
  intro x hx
  obtain ⟨y, hy, hxy⟩ := happroxT x hx
  have hycover : y ∈ ⋃ z ∈ centers, Metric.ball z (ε / 2) := hcover hy
  rcases Set.mem_iUnion.mp hycover with ⟨z, hz⟩
  rcases Set.mem_iUnion.mp hz with ⟨hzc, hyball⟩
  refine Set.mem_iUnion.mpr ⟨z, Set.mem_iUnion.mpr ⟨hzc, ?_⟩⟩
  apply Metric.mem_ball.mpr
  calc
    dist x z ≤ dist x y + dist y z := dist_triangle _ _ _
    _ < ε / 2 + ε / 2 := add_lt_add hxy (Metric.mem_ball.mp hyball)
    _ = ε := by ring

theorem periodic5DElevenQuartersBall_totallyBounded (B : ℝ) (hB : 0 ≤ B) :
    TotallyBounded (periodic5DElevenQuartersBallInHminusThree B) :=
  periodic5D_totallyBounded_of_compact_approximation
    (periodic5DElevenQuartersBall_compact_approximation B hB)

theorem isCompact_closure_periodic5DElevenQuartersBall (B : ℝ) (hB : 0 ≤ B) :
    IsCompact (closure (periodic5DElevenQuartersBallInHminusThree B)) := by
  rw [isCompact_iff_totallyBounded_isComplete]
  exact ⟨(periodic5DElevenQuartersBall_totallyBounded B hB).closure,
    isClosed_closure.isComplete⟩


end Pphi2Clean.Continuum
