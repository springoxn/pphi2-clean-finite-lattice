import AImathPPhi2Clean.Periodic5DAtomicMarginal
import Mathlib.Order.Filter.AtTopBot.CountablyGenerated

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Filter Topology

/-- Continuous mapping identifies every real Fourier-family marginal of a weak subsequential limit. -/
theorem periodic5DFixedVolume_subsequential_limit_fourierFamily
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool)
    (ν : ProbabilityMeasure Periodic5DCompletion) (ns : ℕ → ℕ)
    (hns : Tendsto ns atTop atTop)
    (hlim : Tendsto (fun k => periodic5DFixedVolumeProbabilityMeasure L mass hL hmass (ns k)) atTop (𝓝 ν)) :
    ν.map (periodic5DFourierFamilyProjection L hL modes useSine) =
      periodicResolventTargetProbabilityMeasure 5 m L mass hmass
        (periodic5DFourierTestFamily L hL modes useSine) := by
  have hmap := ProbabilityMeasure.tendsto_map_of_tendsto_of_continuous
    _ _ hlim (continuous_periodic5DFourierFamilyProjection L hL modes useSine)
  exact tendsto_nhds_unique hmap
    ((periodic5DFixedVolume_fourierFamily_marginal_tendsto m L mass hL hmass modes useSine).comp hns)

/-- Every full weak limit has the Fourier marginals supplied by the actual finite-source convergence. -/
theorem periodic5DFixedVolume_weak_limit_fourierFamily
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool)
    (ν : ProbabilityMeasure Periodic5DCompletion)
    (hlim : Tendsto (periodic5DFixedVolumeProbabilityMeasure L mass hL hmass) atTop (𝓝 ν)) :
    ν.map (periodic5DFourierFamilyProjection L hL modes useSine) =
      periodicResolventTargetProbabilityMeasure 5 m L mass hmass
        (periodic5DFourierTestFamily L hL modes useSine) :=
  periodic5DFixedVolume_subsequential_limit_fourierFamily
    m L mass hL hmass modes useSine ν id tendsto_id hlim

/-- Any two weak subsequential limits of the actual atomic 5D laws coincide. -/
theorem periodic5DFixedVolume_subsequential_limits_eq
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (μ ν : ProbabilityMeasure Periodic5DCompletion) (ns ms : ℕ → ℕ)
    (hns : Tendsto ns atTop atTop) (hms : Tendsto ms atTop atTop)
    (hμ : Tendsto (fun k => periodic5DFixedVolumeProbabilityMeasure L mass hL hmass (ns k)) atTop (𝓝 μ))
    (hν : Tendsto (fun k => periodic5DFixedVolumeProbabilityMeasure L mass hL hmass (ms k)) atTop (𝓝 ν)) : μ = ν := by
  apply periodic5D_probabilityMeasure_ext_of_fourierFamily_marginals L hL μ ν
  intro m modes useSine
  rw [periodic5DFixedVolume_subsequential_limit_fourierFamily m L mass hL hmass modes useSine μ ns hns hμ,
    periodic5DFixedVolume_subsequential_limit_fourierFamily m L mass hL hmass modes useSine ν ms hms hν]

/-- Tightness and finite Fourier convergence give full weak convergence, without an assumed target. -/
theorem periodic5DFixedVolume_weak_limit_exists
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    ∃ μ : ProbabilityMeasure Periodic5DCompletion,
      Tendsto (periodic5DFixedVolumeProbabilityMeasure L mass hL hmass) atTop (𝓝 μ) := by
  obtain ⟨ms0, μ, hms0, hμ⟩ := periodic5DFixedVolume_prokhorov_subsequence L mass hL hmass id tendsto_id
  refine ⟨μ, ?_⟩
  apply Filter.tendsto_of_subseq_tendsto
  intro ns hns
  obtain ⟨ms, ν, hms, hν⟩ := periodic5DFixedVolume_prokhorov_subsequence L mass hL hmass ns hns
  have heq : ν = μ := periodic5DFixedVolume_subsequential_limits_eq L mass hL hmass ν μ
    (fun k => ns (ms k)) ms0 (hns.comp hms.tendsto_atTop) hms0.tendsto_atTop hν hμ
  exact ⟨ms, heq ▸ hν⟩

/-- Existence and uniqueness of the full weak limit of the actual 5D finite-source laws. -/
theorem periodic5DFixedVolume_weak_limit_existsUnique
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    ∃! μ : ProbabilityMeasure Periodic5DCompletion,
      Tendsto (periodic5DFixedVolumeProbabilityMeasure L mass hL hmass) atTop (𝓝 μ) := by
  obtain ⟨μ, hμ⟩ := periodic5DFixedVolume_weak_limit_exists L mass hL hmass
  exact ⟨μ, hμ, fun ν hν => tendsto_nhds_unique hν hμ⟩

#print axioms periodic5DFixedVolume_weak_limit_existsUnique
#print axioms periodic5DFixedVolume_subsequential_limits_eq
end Pphi2Clean.Continuum
