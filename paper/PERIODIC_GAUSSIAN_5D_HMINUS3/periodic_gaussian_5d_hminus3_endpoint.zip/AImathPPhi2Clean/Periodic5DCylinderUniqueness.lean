import AImathPPhi2Clean.Periodic5DWeightedCarrier
import Mathlib.MeasureTheory.Constructions.Cylinders
import Mathlib.MeasureTheory.Constructions.BorelSpace.Complex
import Mathlib.MeasureTheory.Measure.Prokhorov
import Mathlib.MeasureTheory.Function.SpecialFunctions.Basic
import Mathlib.MeasureTheory.Measure.Typeclasses.Finite

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory 

theorem periodic5D_coordinate_continuous (k : Periodic5DIndex) :
    Continuous (fun x : Periodic5DCompletion => x k) :=
  (lp.evalCLM ℝ (fun _ : Periodic5DIndex => ℂ) 2 k).continuous

def periodic5DCoordinateCylinder
    (s : Finset Periodic5DIndex) (S : Set (∀ i : s, ℂ)) : Set Periodic5DCompletion :=
  (fun x : Periodic5DCompletion => s.restrict (x : Periodic5DIndex → ℂ)) ⁻¹' S
def periodic5DMeasurableCylinders : Set (Set Periodic5DCompletion) :=
  {A | ∃ t ∈ measurableCylinders (fun _ : Periodic5DIndex => ℂ),
    (fun x : Periodic5DCompletion => (x : Periodic5DIndex → ℂ)) ⁻¹' t = A}
theorem measurable_periodic5D_coordinate_inclusion :
    Measurable (fun x : Periodic5DCompletion =>
      (x : Periodic5DIndex → ℂ)) := by
  rw [measurable_pi_iff]
  intro k
  exact (periodic5D_coordinate_continuous k).measurable
theorem periodic5D_cylinder_mem
    (s : Finset Periodic5DIndex) {S : Set (∀ i : s, ℂ)} (hS : MeasurableSet S) :
    periodic5DCoordinateCylinder s S ∈ periodic5DMeasurableCylinders := by
  refine ⟨cylinder s S, ?_, ?_⟩
  · rw [mem_measurableCylinders]
    exact ⟨s, S, hS, rfl⟩
  · rfl
theorem periodic5D_norm_sq_sublevel_measurable_of_generated_cylinders
    (y : Periodic5DCompletion) (r : ℝ) :
    @MeasurableSet Periodic5DCompletion
      (MeasurableSpace.generateFrom periodic5DMeasurableCylinders)
      {x | ‖x - y‖ ^ 2 < r} := by
  letI : MeasurableSpace Periodic5DCompletion :=
    MeasurableSpace.generateFrom periodic5DMeasurableCylinders
  have hcoord : ∀ i : Periodic5DIndex, Measurable (fun x : Periodic5DCompletion => x i) := by
    intro i A hA
    let j : {k // k ∈ ({i} : Finset Periodic5DIndex)} := ⟨i, by simp⟩
    have hS : MeasurableSet {z : ∀ k : ({i} : Finset Periodic5DIndex), ℂ | z j ∈ A} :=
      hA.preimage (measurable_pi_apply j)
    have hcyl := periodic5D_cylinder_mem ({i} : Finset Periodic5DIndex) hS
    have heq : Set.preimage (fun x : Periodic5DCompletion => x i) A =
        periodic5DCoordinateCylinder {i} {z | z j ∈ A} := by
      ext x
      rfl
    rw [heq]
    exact MeasurableSpace.measurableSet_generateFrom hcyl
  have hsum : Measurable (fun x : Periodic5DCompletion =>
      ∑' i : Periodic5DIndex, ‖x i - y i‖ ^ 2) :=
    Measurable.tsum (fun i => ((hcoord i).sub measurable_const).norm.pow_const 2)
  have hnorm : Measurable (fun x : Periodic5DCompletion => ‖x - y‖ ^ 2) := by
    convert hsum using 1
    funext x
    simpa using (lp.norm_rpow_eq_tsum
      (by norm_num : 0 < (2 : ENNReal).toReal) (x - y))
  exact measurableSet_Iio.preimage hnorm
def Periodic5DCylinderBorelGenerationInput : Prop :=
  MeasurableSpace.generateFrom periodic5DMeasurableCylinders =
    borel Periodic5DCompletion
open TopologicalSpace in
theorem periodic5D_cylinder_borel_generation : Periodic5DCylinderBorelGenerationInput := by
  letI : TopologicalSpace.SeparableSpace Periodic5DCompletion :=
    periodic5DCompletion_separable
  haveI : SecondCountableTopology Periodic5DCompletion := inferInstance
  change MeasurableSpace.generateFrom periodic5DMeasurableCylinders =
    borel Periodic5DCompletion
  apply le_antisymm
  · apply MeasurableSpace.generateFrom_le
    rintro A ⟨t, ht, rfl⟩
    rw [mem_measurableCylinders] at ht
    rcases ht with ⟨s, S, hS, rfl⟩
    exact hS.preimage ((Finset.measurable_restrict s).comp
      measurable_periodic5D_coordinate_inclusion)
  · letI : MeasurableSpace Periodic5DCompletion :=
      MeasurableSpace.generateFrom periodic5DMeasurableCylinders
    have hball (y : Periodic5DCompletion) (r : ℝ) (hr : 0 < r) :
        MeasurableSet (Metric.ball y r) := by
      have heq : Metric.ball y r = {x | ‖x - y‖ ^ 2 < r ^ 2} := by
        ext x
        simp only [Metric.mem_ball, dist_eq_norm, Set.mem_setOf_eq]
        constructor <;> intro h <;> nlinarith [norm_nonneg (x - y)]
      rw [heq]
      exact periodic5D_norm_sq_sublevel_measurable_of_generated_cylinders y (r ^ 2)
    apply MeasurableSpace.generateFrom_le
    intro U hU
    change IsOpen U at hU
    let F : Set (Set Periodic5DCompletion) :=
      {V | ∃ y r, 0 < r ∧ V = Metric.ball y r ∧ V ⊆ U}
    have hFopen : ∀ V ∈ F, IsOpen V := by
      rintro V ⟨y, r, hr, rfl, hsub⟩
      exact Metric.isOpen_ball
    have hFcover : ⋃₀ F = U := by
      ext x
      constructor
      · rintro ⟨V, ⟨y, r, hr, rfl, hsub⟩, hx⟩
        exact hsub hx
      · intro hx
        obtain ⟨r, hr, hsub⟩ :=
          (Metric.isOpen_iff (α := Periodic5DCompletion)).mp hU x hx
        exact Set.mem_sUnion.mpr
          ⟨Metric.ball x r, ⟨x, r, hr, rfl, hsub⟩, Metric.mem_ball_self hr⟩
    obtain ⟨v, hv, hvF, hvcover⟩ := isOpen_sUnion_countable F hFopen
    rw [← hFcover, ← hvcover]
    apply MeasurableSet.sUnion hv
    intro V hV
    rcases hvF hV with ⟨y, r, hr, rfl, hsub⟩
    exact hball y r hr
theorem periodic5D_measure_ext_of_cylinder
    (μ ν : Measure Periodic5DCompletion)
    [IsFiniteMeasure μ] [IsFiniteMeasure ν]
    (hμν : ∀ (s : Finset Periodic5DIndex) (S : Set (∀ i : s, ℂ)),
      MeasurableSet S →
        μ (periodic5DCoordinateCylinder s S) =
          ν (periodic5DCoordinateCylinder s S))
    (huniv : μ (Set.univ) = ν (Set.univ)) : μ = ν := by
  apply ext_of_generate_finite periodic5DMeasurableCylinders
    periodic5D_cylinder_borel_generation.symm
    (isPiSystem_measurableCylinders.comap
      (fun x : Periodic5DCompletion => (x : Periodic5DIndex → ℂ)))
  · intro A hA
    rcases hA with ⟨t, ht, rfl⟩
    rcases (mem_measurableCylinders t).mp ht with ⟨s, S, hS, rfl⟩
    exact hμν s S hS
  · simpa using huniv

theorem periodic5D_probabilityMeasure_ext_of_finite_marginals
    (μ ν : ProbabilityMeasure Periodic5DCompletion)
    (hmarg : ∀ (s : Finset Periodic5DIndex),
      μ.map (fun x : Periodic5DCompletion =>
        s.restrict (x : Periodic5DIndex → ℂ)) =
      ν.map (fun x : Periodic5DCompletion =>
        s.restrict (x : Periodic5DIndex → ℂ))) : μ = ν := by
  apply ProbabilityMeasure.toMeasure_injective
  apply periodic5D_measure_ext_of_cylinder (μ := μ) (ν := ν)
  · intro s S hS
    have hmeas : Measurable (fun x : Periodic5DCompletion =>
        s.restrict (x : Periodic5DIndex → ℂ)) :=
      (Finset.measurable_restrict s).comp
        measurable_periodic5D_coordinate_inclusion
    change (μ : Measure Periodic5DCompletion)
        (periodic5DCoordinateCylinder s S) =
      (ν : Measure Periodic5DCompletion)
        (periodic5DCoordinateCylinder s S)
    rw [periodic5DCoordinateCylinder]
    rw [← Measure.map_apply hmeas hS, ← Measure.map_apply hmeas hS]
    exact congrArg
      (fun ρ : ProbabilityMeasure (∀ i : s, ℂ) =>
        (ρ : Measure (∀ i : s, ℂ)) S) (hmarg s)
  · simp [ProbabilityMeasure.coeFn_def]
end Pphi2Clean.Continuum
