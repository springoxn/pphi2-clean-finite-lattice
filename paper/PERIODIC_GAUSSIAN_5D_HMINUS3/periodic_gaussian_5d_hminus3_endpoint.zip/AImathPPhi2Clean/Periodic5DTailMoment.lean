import AImathPPhi2Clean.Periodic5DProbeMoment
import Mathlib.Analysis.Normed.Group.FunctionSeries

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice Filter
open scoped Topology

/-- Explicit finite-complement moment bound; the weight can be specialized to H^-3. -/
theorem periodic5DProbeMoment_tail_le
    (w : (Fin 5 → ℤ) → ℝ) (hw : Summable w) (hw0 : ∀ k, 0 ≤ w k)
    (K : Finset (Fin 5 → ℤ))
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) :
    (∑' k : {k : Fin 5 → ℤ // k ∉ K}, w k *
      periodic5DComplexFourierProbeMoment N a mass L ha hmass hL k) ≤
      (2 * (mass⁻¹ ^ 2 * L ^ 5)) * ∑' k : {k : Fin 5 → ℤ // k ∉ K}, w k := by
  let C := 2 * (mass⁻¹ ^ 2 * L ^ 5)
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hs : Summable (fun k : {k : Fin 5 → ℤ // k ∉ K} => w k * C) :=
    (hw.subtype _).mul_right C
  have hn (k : {k : Fin 5 → ℤ // k ∉ K}) : 0 ≤ w k *
      periodic5DComplexFourierProbeMoment N a mass L ha hmass hL k :=
    mul_nonneg (hw0 k) (periodic5DComplexFourierProbeMoment_nonneg N a mass L ha hmass hL k)
  have hb (k : {k : Fin 5 → ℤ // k ∉ K}) : w k *
      periodic5DComplexFourierProbeMoment N a mass L ha hmass hL k ≤ w k * C :=
    mul_le_mul_of_nonneg_left
      (periodic5DComplexFourierProbeMoment_le N a mass L ha hmass hvol hL k) (hw0 k)
  calc
    _ ≤ ∑' k : {k : Fin 5 → ℤ // k ∉ K}, w k * C :=
      (hs.of_nonneg_of_le hn hb).tsum_le_tsum hb hs
    _ = _ := by rw [tsum_mul_right]; exact mul_comm _ _

/-- The explicit upper bound tends to zero along finite Fourier truncations. -/
theorem periodic5DProbeMoment_tail_bound_tendsto_zero
    (w : (Fin 5 → ℤ) → ℝ) (_hw : Summable w) (mass L : ℝ) :
    Tendsto (fun K : Finset (Fin 5 → ℤ) =>
      (2 * (mass⁻¹ ^ 2 * L ^ 5)) * ∑' k : {k : Fin 5 → ℤ // k ∉ K}, w k)
      atTop (𝓝 0) := by
  simpa only [mul_zero] using (tendsto_tsum_compl_atTop_zero w).const_mul
    (2 * (mass⁻¹ ^ 2 * L ^ 5))

end Pphi2Clean.Continuum
