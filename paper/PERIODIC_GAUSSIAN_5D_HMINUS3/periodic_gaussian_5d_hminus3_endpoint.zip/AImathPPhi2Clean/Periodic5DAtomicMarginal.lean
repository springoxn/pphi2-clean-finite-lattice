import AImathPPhi2Clean.Periodic5DFiniteMarginal
import AImathPPhi2Clean.Periodic5DFourierProjection
import AImathPPhi2Clean.Periodic5DTightness
import AImathPPhi2Clean.FiniteRealFamilyMeasure

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice

theorem periodic5DFourierCoordinate_finiteSource
    (N : ℕ) [NeZero N] (a L : ℝ) (ha : 0 < a) (hL : 0 < L)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)))
    (k : Periodic5DIndex) :
    periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L ω k /
      (Real.sqrt (periodic5DHminusThreeWeight k) : ℂ) = periodic5DRawAtomicLift N a L hL ω k := by
  have heq := congrFun (periodic5DRawWeightedLift_eq_finiteSourceFourierLift
    3 periodic5DHminusThreeWeight_summable N a L ha hL ω) k
  have hsqrt : (Real.sqrt (periodic5DHminusThreeWeight k) : ℂ) ≠ 0 := by
    exact_mod_cast (Real.sqrt_pos.mpr (periodic5DSobolevWeight_pos 3 k)).ne'
  calc
    _ = ((Real.sqrt (periodic5DHminusThreeWeight k) : ℂ) *
        periodic5DRawAtomicLift N a L hL ω k) /
        (Real.sqrt (periodic5DHminusThreeWeight k) : ℂ) := by rw [heq]
    _ = _ := mul_div_cancel_left₀ _ hsqrt

theorem periodic5DFourierFamilyProjection_finiteSource_map
    (m : ℕ) (N : ℕ) [NeZero N] (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    (periodic5DFiniteSourceGaussianMeasure N (L / (N : ℝ)) mass L
      (div_pos hL (Nat.cast_pos.mpr (NeZero.pos N))) hmass).map
        (periodic5DFourierFamilyProjection L hL modes useSine) =
      physicalFamilyEvalMeasure 5 N m (L / (N : ℝ)) mass
        (div_pos hL (Nat.cast_pos.mpr (NeZero.pos N))) hmass
        (periodic5DFourierTestFamily L hL modes useSine) := by
  let a : ℝ := L / (N : ℝ)
  let ha : 0 < a := div_pos hL (Nat.cast_pos.mpr (NeZero.pos N))
  let H : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)) →
      EuclideanSpace ℝ (Fin m) :=
    fun ω => periodic5DFourierFamilyProjection L hL modes useSine
      (periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L ω)
  have hmeasH : Measurable H := (continuous_periodic5DFourierFamilyProjection L hL modes useSine).measurable.comp
    (measurable_periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L)
  unfold periodic5DFiniteSourceGaussianMeasure
  rw [Measure.map_map (continuous_periodic5DFourierFamilyProjection L hL modes useSine).measurable
    (measurable_periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L)]
  have hmeasEval : Measurable
      (physicalFamilyEvalMap 5 N m a mass ha hmass
        (periodic5DFourierTestFamily L hL modes useSine)) := by
    apply (PiLp.continuousLinearEquiv 2 ℝ (fun _ : Fin m => ℝ)).symm.continuous.measurable.comp
    apply measurable_pi_lambda
    intro i
    exact (measurable_pi_apply _).comp (comap_measurable _)
  unfold physicalFamilyEvalMeasure physicalGJMeasure
  rw [Measure.map_map hmeasEval (latticeEmbedLift_measurable (physicalTestEval 5 N a))]
  congr 1
  funext ω
  apply (PiLp.continuousLinearEquiv 2 ℝ (fun _ : Fin m => ℝ)).injective
  funext i
  change (if useSine i then
      (periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L ω (modes i) /
        (Real.sqrt (periodic5DHminusThreeWeight (modes i)) : ℂ)).im
    else
      (periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L ω (modes i) /
        (Real.sqrt (periodic5DHminusThreeWeight (modes i)) : ℂ)).re) =
    (latticeEmbedLift (physicalTestEval 5 N a) ω
      (periodic5DFourierTestFamily L hL modes useSine i))
  have hcoord := periodic5DFourierCoordinate_finiteSource N a L ha hL ω (modes i)
  rw [hcoord]
  by_cases hi : useSine i = true
  · simp [periodic5DFourierTestFamily, periodicFourierTestFamily, hi,
      periodic5DRawAtomicLift, periodic5DComplexFourierProbe]
  · have hi' : useSine i = false := Bool.eq_false_of_not_eq_true hi
    simp [periodic5DFourierTestFamily, periodicFourierTestFamily, hi',
      periodic5DRawAtomicLift, periodic5DComplexFourierProbe]

theorem periodic5DFixedVolume_fourierFamily_marginal_tendsto
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    Filter.Tendsto
      (fun n : ℕ =>
        (periodic5DFixedVolumeProbabilityMeasure L mass hL hmass n).map
          (periodic5DFourierFamilyProjection L hL modes useSine))
      Filter.atTop
      (nhds (periodicResolventTargetProbabilityMeasure 5 m L mass hmass
        (periodic5DFourierTestFamily L hL modes useSine))) := by
  have htarget := periodic5DFourierTestFamily_finiteMeasure_tendsto
    m L mass hL hmass modes useSine
  apply Filter.Tendsto.congr' ?_ htarget
  filter_upwards [] with n
  let N := n + 1
  let a : ℝ := L / (N : ℝ)
  have ha : 0 < a := by dsimp [a, N]; exact div_pos hL (Nat.cast_pos.mpr (Nat.succ_pos n))
  have hseq :
      (periodic5DFixedVolumeProbabilityMeasure L mass hL hmass n).map
          (periodic5DFourierFamilyProjection L hL modes useSine) =
        physicalFamilyEvalProbabilityMeasure 5 N m a mass ha hmass
          (periodic5DFourierTestFamily L hL modes useSine) := by
    apply ProbabilityMeasure.toMeasure_injective
    rw [ProbabilityMeasure.toMeasure_map]
    change Measure.map (periodic5DFourierFamilyProjection L hL modes useSine)
        (periodic5DFiniteSourceGaussianMeasure N a mass L ha hmass) = _
    exact periodic5DFourierFamilyProjection_finiteSource_map m N L mass hL hmass modes useSine
  simpa [N, a] using hseq.symm

end Pphi2Clean.Continuum

