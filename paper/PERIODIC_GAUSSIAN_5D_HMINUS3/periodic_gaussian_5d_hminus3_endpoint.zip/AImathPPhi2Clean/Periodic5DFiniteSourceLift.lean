import AImathPPhi2Clean.Periodic5DRawAtomicLift
import AImathPPhi2Clean.Periodic5DWeightedCarrier
import AImathPPhi2Clean.RealFourierTestFunctions

noncomputable section
namespace Pphi2Clean.Continuum

open MeasureTheory Pphi2Clean.UpstreamLattice

def periodic5DSitePhase (N : ℕ) [NeZero N] (a L : ℝ)
    (j : Fin (Fintype.card (FinLatticeSites 5 N))) (k : Periodic5DIndex) : ℝ :=
  (2 * Real.pi / L) * ∑ i, (k i : ℝ) *
    latticePhysicalPoint 5 N a ((Fintype.equivFin (FinLatticeSites 5 N)).symm j) i

def periodic5DSiteSequence (N : ℕ) [NeZero N] (a L : ℝ)
    (j : Fin (Fintype.card (FinLatticeSites 5 N))) : Periodic5DIndex → ℂ :=
  fun k => ((a ^ 5 * Real.cos (periodic5DSitePhase N a L j k) : ℝ) : ℂ) +
    ((a ^ 5 * Real.sin (periodic5DSitePhase N a L j k) : ℝ) : ℂ) * Complex.I

theorem periodic5DSiteSequence_mem_carrier (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ)
    (j : Fin (Fintype.card (FinLatticeSites 5 N))) :
    periodic5DSiteSequence N a L j ∈ periodic5DCarrier s := by
  rw [periodic5DCarrier]
  have hmajor : Summable (fun k : Periodic5DIndex =>
      a ^ 10 * periodic5DSobolevWeight s k) := hs.mul_left (a ^ 10)
  apply hmajor.of_nonneg_of_le
  · intro k
    exact mul_nonneg (periodic5DSobolevWeight_nonneg s k) (sq_nonneg _)
  · intro k
    let θ := periodic5DSitePhase N a L j k
    have hnorm : ‖periodic5DSiteSequence N a L j k‖ ^ 2 = a ^ 10 := by
      dsimp [periodic5DSiteSequence, θ]
      rw [Complex.sq_norm, Complex.normSq_add_mul_I]
      calc
        (a ^ 5 * Real.cos (periodic5DSitePhase N a L j k)) ^ 2 +
            (a ^ 5 * Real.sin (periodic5DSitePhase N a L j k)) ^ 2 =
            a ^ 10 * (Real.cos (periodic5DSitePhase N a L j k) ^ 2 +
              Real.sin (periodic5DSitePhase N a L j k) ^ 2) := by ring
        _ = a ^ 10 := by rw [Real.cos_sq_add_sin_sq, mul_one]
    rw [hnorm]
    exact (mul_comm _ _).le

def periodic5DSiteWeightedSequence (s : ℝ) (N : ℕ) [NeZero N]
    (a L : ℝ) (j : Fin (Fintype.card (FinLatticeSites 5 N))) : Periodic5DIndex → ℂ :=
  fun k => (Real.sqrt (periodic5DSobolevWeight s k) : ℂ) *
    periodic5DSiteSequence N a L j k

theorem periodic5DSiteWeightedSequence_memLp (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ)
    (j : Fin (Fintype.card (FinLatticeSites 5 N))) :
    Memℓp (periodic5DSiteWeightedSequence s N a L j) 2 :=
  periodic5D_weighted_coefficients_memLp2 s (periodic5DSiteSequence N a L j)
    (periodic5DSiteSequence_mem_carrier s hs N a L j)

def periodic5DSiteVector (s : ℝ) (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ)
    (j : Fin (Fintype.card (FinLatticeSites 5 N))) : Periodic5DCompletion :=
  ⟨periodic5DSiteWeightedSequence s N a L j,
    periodic5DSiteWeightedSequence_memLp s hs N a L j⟩

def periodic5DFiniteSourceCoefficientMap (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ)
    (c : Fin (Fintype.card (FinLatticeSites 5 N)) → ℝ) : Periodic5DCompletion :=
  ∑ j : Fin (Fintype.card (FinLatticeSites 5 N)),
    c j • periodic5DSiteVector s hs N a L j

theorem continuous_periodic5DFiniteSourceCoefficientMap (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ) :
    Continuous (periodic5DFiniteSourceCoefficientMap s hs N a L) := by
  unfold periodic5DFiniteSourceCoefficientMap
  exact continuous_finsetSum Finset.univ (fun j _ =>
    (continuous_apply j).smul continuous_const)

def periodic5DFiniteSourceFourierLift (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N))) :
    Periodic5DCompletion :=
  periodic5DFiniteSourceCoefficientMap s hs N a L
    (fun j => ω (Pi.single j (1 : ℝ) : FiniteLatticeField
      (Fintype.card (FinLatticeSites 5 N))) )

theorem measurable_periodic5DFiniteSourceFourierLift (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ) :
    Measurable (periodic5DFiniteSourceFourierLift s hs N a L) := by
  unfold periodic5DFiniteSourceFourierLift
  have hcoords : Measurable (fun ω : FiniteLatticeConfiguration
      (Fintype.card (FinLatticeSites 5 N)) =>
        fun j : Fin (Fintype.card (FinLatticeSites 5 N)) =>
          ω (Pi.single j (1 : ℝ) : FiniteLatticeField
            (Fintype.card (FinLatticeSites 5 N)))) := by
    apply measurable_pi_lambda
    intro j
    exact (measurable_pi_apply (Pi.single j (1 : ℝ) : FiniteLatticeField
      (Fintype.card (FinLatticeSites 5 N)))).comp (comap_measurable _)
  exact (continuous_periodic5DFiniteSourceCoefficientMap s hs N a L).measurable.comp hcoords

theorem periodic5DFiniteSourceFourierLift_apply (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)))
    (k : Periodic5DIndex) :
    periodic5DFiniteSourceFourierLift s hs N a L ω k =
      ∑ j : Fin (Fintype.card (FinLatticeSites 5 N)),
        (ω (Pi.single j (1 : ℝ) : FiniteLatticeField
          (Fintype.card (FinLatticeSites 5 N))) : ℂ) *
          periodic5DSiteWeightedSequence s N a L j k := by
  change (⇑(periodic5DFiniteSourceCoefficientMap s hs N a L
    (fun j => ω (Pi.single j (1 : ℝ) : FiniteLatticeField
      (Fintype.card (FinLatticeSites 5 N)))))) k = _
  rw [periodic5DFiniteSourceCoefficientMap, lp.coeFn_sum]
  simp only [Finset.sum_apply, lp.coeFn_smul, Pi.smul_apply,
    periodic5DSiteVector, Complex.real_smul]

theorem periodic5DRawAtomicLift_eq_site_sum (N : ℕ) [NeZero N]
    (a L : ℝ) (ha : 0 < a) (hL : 0 < L)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N))) :
    periodic5DRawAtomicLift N a L hL ω =
      fun k => ∑ j : Fin (Fintype.card (FinLatticeSites 5 N)),
        (ω (Pi.single j (1 : ℝ) : FiniteLatticeField
          (Fintype.card (FinLatticeSites 5 N))) : ℂ) *
          periodic5DSiteSequence N a L j k := by
  have hcos (k : Periodic5DIndex) :
      (latticeEmbedLift (physicalTestEval 5 N a) ω)
          (periodicCosineTest 5 L k hL) =
        ∑ j : Fin (Fintype.card (FinLatticeSites 5 N)),
          ω (Pi.single j (1 : ℝ) : FiniteLatticeField
            (Fintype.card (FinLatticeSites 5 N))) *
            (a ^ 5 * Real.cos (periodic5DSitePhase N a L j k)) := by
    rw [latticeEmbedLift_eval]
    apply Finset.sum_congr rfl
    intro j hj
    rw [physicalTestEval_periodicCosineTest_apply 5 N a L ha k hL j]
    rfl
  have hsin (k : Periodic5DIndex) :
      (latticeEmbedLift (physicalTestEval 5 N a) ω)
          (periodicSineTest 5 L k hL) =
        ∑ j : Fin (Fintype.card (FinLatticeSites 5 N)),
          ω (Pi.single j (1 : ℝ) : FiniteLatticeField
            (Fintype.card (FinLatticeSites 5 N))) *
            (a ^ 5 * Real.sin (periodic5DSitePhase N a L j k)) := by
    rw [latticeEmbedLift_eval]
    apply Finset.sum_congr rfl
    intro j hj
    rw [physicalTestEval_periodicSineTest_apply 5 N a L ha k hL j]
    rfl
  funext k
  simp only [periodic5DRawAtomicLift, periodic5DComplexFourierProbe]
  rw [hcos k, hsin k]
  simp only [Complex.ofReal_sum, Complex.ofReal_mul, Complex.ofReal_cos,
    Complex.ofReal_sin, periodic5DSiteSequence]
  rw [Finset.sum_mul, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem periodic5DRawWeightedLift_eq_finiteSourceFourierLift (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a L : ℝ) (ha : 0 < a) (hL : 0 < L)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N))) :
    (fun k => (Real.sqrt (periodic5DSobolevWeight s k) : ℂ) *
        periodic5DRawAtomicLift N a L hL ω k) =
      fun k => periodic5DFiniteSourceFourierLift s hs N a L ω k := by
  funext k
  rw [periodic5DRawAtomicLift_eq_site_sum N a L ha hL ω]
  rw [periodic5DFiniteSourceFourierLift_apply]
  simp only [periodic5DSiteWeightedSequence]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  ring

end Pphi2Clean.Continuum
