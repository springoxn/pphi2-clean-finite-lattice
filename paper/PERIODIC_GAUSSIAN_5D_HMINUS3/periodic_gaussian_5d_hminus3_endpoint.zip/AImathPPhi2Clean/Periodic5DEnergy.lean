import AImathPPhi2Clean.Periodic5DHminusThreeTail

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice

/-- Uniform total energy for any summable nonnegative Fourier weight. -/
theorem periodic5DRawAtomicLift_integral_energy_le
    (w : (Fin 5 → ℤ) → ℝ) (hw : Summable w) (hw0 : ∀ k, 0 ≤ w k)
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) :
    (∫ ω, ∑' k : Fin 5 → ℤ, w k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
      finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) ≤
      (2 * (mass⁻¹ ^ 2 * L ^ 5)) * ∑' k : Fin 5 → ℤ, w k := by
  have hsum (f : (Fin 5 → ℤ) → ℝ) : (∑' k : {k : Fin 5 → ℤ // k ∉ (∅ : Finset (Fin 5 → ℤ))}, f k) = ∑' k, f k := (Equiv.subtypeUnivEquiv (fun k => Finset.notMem_empty k)).tsum_eq f
  have h := periodic5DRawAtomicLift_integral_tail_le w hw hw0 ∅ N a mass L ha hmass hvol hL
  rw [hsum w] at h
  convert h using 1
  congr 1
  funext ω
  exact (hsum (fun k => w k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2)).symm

theorem periodic5DRawAtomicLift_integral_energy_eleven_quarters_le
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) :
    (∫ ω, ∑' k : Fin 5 → ℤ, periodic5DSobolevWeight (11/4) k *
      ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
      finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) ≤
      (2 * (mass⁻¹ ^ 2 * L ^ 5)) * ∑' k : Fin 5 → ℤ, periodic5DSobolevWeight (11/4) k := by
  exact periodic5DRawAtomicLift_integral_energy_le _
    periodic5DSobolevWeight_eleven_quarters_summable
    (periodic5DSobolevWeight_nonneg (11/4)) N a mass L ha hmass hvol hL

end Pphi2Clean.Continuum
