import AImathPPhi2Clean.Periodic5DCylinderUniqueness
import Mathlib

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory

def periodic5DFourierFamilyProjection {m : ℕ} (L : ℝ) (hL : 0 < L)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    Periodic5DCompletion → EuclideanSpace ℝ (Fin m) := fun x =>
  WithLp.toLp 2 (fun i =>
    let z := x (modes i) / (Real.sqrt (periodic5DHminusThreeWeight (modes i)) : ℂ)
    if useSine i then z.im else z.re)

theorem continuous_periodic5DFourierFamilyProjection {m : ℕ} (L : ℝ) (hL : 0 < L)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    Continuous (periodic5DFourierFamilyProjection L hL modes useSine) := by
  unfold periodic5DFourierFamilyProjection
  apply (PiLp.continuousLinearEquiv 2 ℝ (fun _ : Fin m => ℝ)).symm.continuous.comp
  apply continuous_pi
  intro i
  dsimp
  split
  · exact Complex.continuous_im.comp
      ((periodic5D_coordinate_continuous (modes i)).div_const _)
  · exact Complex.continuous_re.comp
      ((periodic5D_coordinate_continuous (modes i)).div_const _)

/-- Joint real and imaginary Fourier families determine the complex cylinders. -/
theorem periodic5D_probabilityMeasure_ext_of_fourierFamily_marginals
    (L : ℝ) (hL : 0 < L) (μ ν : ProbabilityMeasure Periodic5DCompletion)
    (hmarg : ∀ (m : ℕ) (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool),
      μ.map (periodic5DFourierFamilyProjection L hL modes useSine) =
      ν.map (periodic5DFourierFamilyProjection L hL modes useSine)) : μ = ν := by
  apply periodic5D_probabilityMeasure_ext_of_finite_marginals
  intro s
  let e : (s × Bool) ≃ Fin (Fintype.card (s × Bool)) := Fintype.equivFin _
  let modes : Fin (Fintype.card (s × Bool)) → Periodic5DIndex := fun j => (e.symm j).1.1
  let useSine : Fin (Fintype.card (s × Bool)) → Bool := fun j => (e.symm j).2
  let P := periodic5DFourierFamilyProjection L hL modes useSine
  let R : EuclideanSpace ℝ (Fin (Fintype.card (s × Bool))) → (∀ i : s, ℂ) :=
    fun y i => (Real.sqrt (periodic5DHminusThreeWeight i.1) : ℂ) *
      ((y (e (i, false)) : ℂ) + (y (e (i, true)) : ℂ) * Complex.I)
  have hR : Measurable R := by
    have hcontinuous : Continuous R := by
      apply continuous_pi
      intro i
      dsimp [R]
      fun_prop
    exact hcontinuous.measurable
  have hP : Measurable P := (continuous_periodic5DFourierFamilyProjection L hL modes useSine).measurable
  have hfactor : R ∘ P = (fun x : Periodic5DCompletion => s.restrict (x : Periodic5DIndex → ℂ)) := by
    funext x i
    have hw : (Real.sqrt (periodic5DHminusThreeWeight i.1) : ℂ) ≠ 0 := by
      exact_mod_cast (Real.sqrt_pos.mpr (periodic5DSobolevWeight_pos 3 i.1)).ne'
    change (Real.sqrt (periodic5DHminusThreeWeight i.1) : ℂ) *
      (((P x) (e (i, false)) : ℂ) + ((P x) (e (i, true)) : ℂ) * Complex.I) = x i.1
    simp only [P, periodic5DFourierFamilyProjection, modes, useSine, Equiv.symm_apply_apply, Bool.false_eq_true, ite_false, ite_true]
    rw [Complex.re_add_im]
    exact mul_div_cancel₀ _ hw
  have hmap (ρ : ProbabilityMeasure Periodic5DCompletion) :
      (ρ.map P).map R = ρ.map (fun x : Periodic5DCompletion => s.restrict (x : Periodic5DIndex → ℂ)) := by
    apply ProbabilityMeasure.toMeasure_injective
    exact (Measure.map_map hR hP).trans (congrArg (fun f => Measure.map f (ρ : Measure _)) hfactor)
  rw [← hmap μ, ← hmap ν, hmarg _ modes useSine]


end Pphi2Clean.Continuum
