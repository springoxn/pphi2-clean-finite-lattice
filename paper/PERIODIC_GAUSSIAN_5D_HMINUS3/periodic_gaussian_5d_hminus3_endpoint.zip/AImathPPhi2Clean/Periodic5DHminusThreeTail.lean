import AImathPPhi2Clean.Periodic5DRawTail
import AImathPPhi2Clean.Periodic5DSobolevWeights

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice Filter
open scoped Topology

theorem periodic5DRawAtomicLift_integral_hminusThree_tail_le
    (K : Finset Periodic5DIndex)
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) :
    (∫ ω, ∑' k : {k : Periodic5DIndex // k ∉ K},
      periodic5DHminusThreeWeight k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
      finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) ≤
      (2 * (mass⁻¹ ^ 2 * L ^ 5)) *
        ∑' k : {k : Periodic5DIndex // k ∉ K}, periodic5DHminusThreeWeight k := by
  apply periodic5DRawAtomicLift_integral_tail_le
    periodic5DHminusThreeWeight periodic5DHminusThreeWeight_summable
    (fun k => periodic5DSobolevWeight_nonneg 3 k)
    K N a mass L ha hmass hvol hL

theorem periodic5DHminusThree_uniform_tail_bound_tendsto_zero (mass L : ℝ) :
    Tendsto (fun K : Finset Periodic5DIndex =>
      (2 * (mass⁻¹ ^ 2 * L ^ 5)) *
        ∑' k : {k : Periodic5DIndex // k ∉ K}, periodic5DHminusThreeWeight k)
      atTop (𝓝 0) :=
  periodic5DProbeMoment_tail_bound_tendsto_zero periodic5DHminusThreeWeight periodic5DHminusThreeWeight_summable mass L

/-- One finite truncation controls every actual finite-source law simultaneously. -/
theorem periodic5DRawAtomicLift_uniform_hminusThree_tail
    (mass L : ℝ) (hmass : 0 < mass) (hL : 0 < L)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ K : Finset Periodic5DIndex, ∀ (N : ℕ) [NeZero N]
      (a : ℝ) (ha : 0 < a) (hvol : a * (N : ℝ) = L),
      (∫ ω, ∑' k : {k : Periodic5DIndex // k ∉ K},
        periodic5DHminusThreeWeight k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
        finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) < ε := by
  obtain ⟨K, hK⟩ := ((tendsto_order.1
    (periodic5DHminusThree_uniform_tail_bound_tendsto_zero mass L)).2 ε hε).exists
  refine ⟨K, ?_⟩
  intro N hN a ha hvol
  exact lt_of_le_of_lt
    (periodic5DRawAtomicLift_integral_hminusThree_tail_le K N a mass L ha hmass hvol hL) hK

end Pphi2Clean.Continuum
