import AImathPPhi2Clean.Periodic5DWeakLimit

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Filter Topology

/-- The H^-3 Gaussian target is constructed from actual five-dimensional source laws. -/
def periodic5DGaussianTarget (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    ProbabilityMeasure Periodic5DCompletion :=
  Classical.choose (periodic5DFixedVolume_weak_limit_exists L mass hL hmass)

theorem periodic5DFixedVolume_weak_tendsto_gaussianTarget
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    Tendsto (periodic5DFixedVolumeProbabilityMeasure L mass hL hmass) atTop
      (𝓝 (periodic5DGaussianTarget L mass hL hmass)) :=
  Classical.choose_spec (periodic5DFixedVolume_weak_limit_exists L mass hL hmass)

theorem periodic5DGaussianTarget_fourierFamily_law
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    (periodic5DGaussianTarget L mass hL hmass).map
      (periodic5DFourierFamilyProjection L hL modes useSine) =
      periodicResolventTargetProbabilityMeasure 5 m L mass hmass
        (periodic5DFourierTestFamily L hL modes useSine) :=
  periodic5DFixedVolume_weak_limit_fourierFamily m L mass hL hmass modes useSine _
    (periodic5DFixedVolume_weak_tendsto_gaussianTarget L mass hL hmass)

theorem periodic5DGaussianTarget_unique_of_fourierFamily_law
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (ν : ProbabilityMeasure Periodic5DCompletion)
    (hν : ∀ (m : ℕ) (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool),
      ν.map (periodic5DFourierFamilyProjection L hL modes useSine) =
        periodicResolventTargetProbabilityMeasure 5 m L mass hmass
          (periodic5DFourierTestFamily L hL modes useSine)) :
    ν = periodic5DGaussianTarget L mass hL hmass := by
  apply periodic5D_probabilityMeasure_ext_of_fourierFamily_marginals L hL
  intro m modes useSine
  rw [hν, periodic5DGaussianTarget_fourierFamily_law]

end Pphi2Clean.Continuum
