import AImathPPhi2Clean.Periodic5DSobolevWeights
import Mathlib.Analysis.Normed.Lp.lpSpace
import Mathlib.Topology.Bases
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic

noncomputable section
namespace Pphi2Clean.Continuum

/-- A single completed sequence space hosts all the weighted 5D carriers. -/
abbrev Periodic5DCompletion := lp (fun _ : Periodic5DIndex => ℂ) 2

instance : MeasurableSpace Periodic5DCompletion := borel Periodic5DCompletion
instance : BorelSpace Periodic5DCompletion := ⟨rfl⟩

def periodic5DWeightedFourierCoefficients (s : ℝ)
    (c : Periodic5DIndex → ℂ) : Periodic5DIndex → ℂ :=
  fun k => (Real.sqrt (periodic5DSobolevWeight s k) : ℂ) * c k

def periodic5DCarrier (s : ℝ) : Set (Periodic5DIndex → ℂ) :=
  {c | Summable (fun k => periodic5DSobolevWeight s k * ‖c k‖ ^ 2)}

/-- The carrier is represented by its weighted coordinates in `lp`. -/
theorem periodic5D_weighted_coefficients_memLp2 (s : ℝ)
    (c : Periodic5DIndex → ℂ)
    (hc : c ∈ periodic5DCarrier s) : Memℓp (periodic5DWeightedFourierCoefficients s c) 2 := by
  rw [memℓp_gen_iff (by norm_num : 0 < (2 : ENNReal).toReal)]
  change Summable (fun k =>
    ‖(Real.sqrt (periodic5DSobolevWeight s k) : ℂ) * c k‖ ^ (2 : ℝ))
  change Summable (fun k => periodic5DSobolevWeight s k * ‖c k‖ ^ 2) at hc
  apply hc.congr
  intro k
  have hw := periodic5DSobolevWeight_nonneg s k
  simp [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _)]
  nlinarith [Real.sq_sqrt hw]

def periodic5DEmbeddingOfCoefficients (s : ℝ) (c : Periodic5DIndex → ℂ)
    (hc : c ∈ periodic5DCarrier s) : Periodic5DCompletion :=
  ⟨periodic5DWeightedFourierCoefficients s c,
    periodic5D_weighted_coefficients_memLp2 s c hc⟩

def periodic5DCarrierNorm (s : ℝ) (c : Periodic5DIndex → ℂ) : ℝ :=
  Real.sqrt (∑' k, periodic5DSobolevWeight s k * ‖c k‖ ^ 2)

theorem periodic5DEmbeddingOfCoefficients_norm_eq (s : ℝ)
    (c : Periodic5DIndex → ℂ) (hc : c ∈ periodic5DCarrier s) :
    ‖periodic5DEmbeddingOfCoefficients s c hc‖ = periodic5DCarrierNorm s c := by
  unfold periodic5DCarrierNorm
  rw [lp.norm_eq_tsum_rpow (by norm_num : 0 < (2 : ENNReal).toReal)]
  rw [Real.sqrt_eq_rpow]
  congr 1
  apply tsum_congr
  intro k
  simp only [periodic5DEmbeddingOfCoefficients, periodic5DWeightedFourierCoefficients]
  have hw := periodic5DSobolevWeight_nonneg s k
  simp [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _)]
  nlinarith [Real.sq_sqrt hw]

theorem periodic5DHminusThreeWeight_nonneg (k : Periodic5DIndex) :
    0 ≤ periodic5DHminusThreeWeight k := periodic5DSobolevWeight_nonneg 3 k

theorem periodic5D_hminus_three_coefficients_mem (c : Periodic5DIndex → ℂ)
    (hc : Summable (fun k => periodic5DHminusThreeWeight k * ‖c k‖ ^ 2)) :
    c ∈ periodic5DCarrier 3 := hc

def periodic5DHminusThreeNorm (c : Periodic5DIndex → ℂ) : ℝ :=
  periodic5DCarrierNorm 3 c

theorem periodic5DHminusThreeEmbedding_norm_eq (c : Periodic5DIndex → ℂ)
    (hc : c ∈ periodic5DCarrier 3) :
    ‖periodic5DEmbeddingOfCoefficients 3 c hc‖ = periodic5DHminusThreeNorm c :=
  periodic5DEmbeddingOfCoefficients_norm_eq 3 c hc

theorem periodic5DCompletion_coordinate_continuous (k : Periodic5DIndex) :
    Continuous (fun x : Periodic5DCompletion => x k) := by
  exact (lp.evalCLM ℝ (fun _ : Periodic5DIndex => ℂ) 2 k).continuous

def periodic5DFiniteProjection (K : Finset Periodic5DIndex)
    (z : {k // k ∈ K} → ℂ) : Periodic5DCompletion :=
  ∑ k : {k // k ∈ K}, lp.single (E := fun _ : Periodic5DIndex => ℂ) 2 k (z k)

theorem periodic5DFiniteProjection_continuous (K : Finset Periodic5DIndex) :
    Continuous (periodic5DFiniteProjection K) := by
  apply continuous_finsetSum
  intro k hk
  exact (lp.singleContinuousAddMonoidHom
    (fun _ : Periodic5DIndex => ℂ) 2 k).continuous.comp (continuous_apply k)

theorem periodic5D_finite_truncations_approx (x : Periodic5DCompletion)
    {eps : ℝ} (heps : 0 < eps) :
    ∃ s : Finset Periodic5DIndex,
      ‖x - ∑ i ∈ s, lp.single (E := fun _ : Periodic5DIndex => ℂ) 2 i (x i)‖ < eps := by
  have hs : HasSum (fun i : Periodic5DIndex =>
      lp.single (E := fun _ : Periodic5DIndex => ℂ) 2 i (x i)) x :=
    lp.hasSum_single (by norm_num : (2 : ENNReal) ≠ ⊤) x
  rw [HasSum, Metric.tendsto_nhds] at hs
  rcases Filter.eventually_atTop.1 (hs eps heps) with ⟨s, hs⟩
  refine ⟨s, ?_⟩
  have hdist := hs s le_rfl
  simpa [dist_eq_norm, norm_sub_rev] using hdist

def periodic5DFiniteSupportSum
    (v : Σ s : Finset Periodic5DIndex, ({i // i ∈ s} → ℂ)) : Periodic5DCompletion :=
  periodic5DFiniteProjection v.1 v.2

theorem periodic5DFiniteSupportSum_continuous :
    Continuous periodic5DFiniteSupportSum := by
  apply continuous_sigma
  intro s
  exact periodic5DFiniteProjection_continuous s

theorem periodic5DFiniteSupportSum_denseRange : DenseRange periodic5DFiniteSupportSum := by
  rw [Metric.denseRange_iff]
  intro x eps heps
  obtain ⟨s, hs⟩ := periodic5D_finite_truncations_approx x heps
  refine ⟨⟨s, fun i => x i⟩, ?_⟩
  simpa [dist_eq_norm, periodic5DFiniteSupportSum, periodic5DFiniteProjection] using hs

theorem periodic5DCompletion_separable :
    TopologicalSpace.SeparableSpace Periodic5DCompletion := by
  have hdense : Dense (Set.range periodic5DFiniteSupportSum) :=
    periodic5DFiniteSupportSum_denseRange
  have hsep : TopologicalSpace.IsSeparable (Set.range periodic5DFiniteSupportSum) :=
    TopologicalSpace.isSeparable_range periodic5DFiniteSupportSum_continuous
  exact (hdense.isSeparable_iff).mp hsep

instance periodic5DCompletionSeparable :
    TopologicalSpace.SeparableSpace Periodic5DCompletion := periodic5DCompletion_separable

instance periodic5DCompletionSecondCountable : SecondCountableTopology Periodic5DCompletion :=
  UniformSpace.secondCountable_of_separable Periodic5DCompletion

end Pphi2Clean.Continuum
