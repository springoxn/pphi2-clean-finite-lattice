import AImathPPhi2Clean.Periodic5DRawAtomicLift
import AImathPPhi2Clean.Periodic5DTailMoment

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice

theorem periodic5DRawAtomicLift_integrable_sq
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hL : 0 < L) (k : Fin 5 → ℤ) :
    Integrable (fun ω => ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2)
      (finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) := by
  let T := numberedLatticeCovarianceGJ 5 N a mass ha hmass
  let fc := latticeTestField (physicalTestEval 5 N a) (periodicCosineTest 5 L k hL)
  let fs := latticeTestField (physicalTestEval 5 N a) (periodicSineTest 5 L k hL)
  have hc := (finiteCovarianceGaussianMeasure_eval_hasGaussianLaw T fc).memLp_two.integrable_sq
  have hs := (finiteCovarianceGaussianMeasure_eval_hasGaussianLaw T fs).memLp_two.integrable_sq
  apply (hc.add hs).congr
  filter_upwards [] with ω
  change (ω fc) ^ 2 + (ω fs) ^ 2 = _
  change _ = ‖periodic5DComplexFourierProbe L hL k (latticeEmbedLift (physicalTestEval 5 N a) ω)‖ ^ 2
  rw [periodic5DComplexFourierProbe_norm_sq, latticeEmbedLift_eval_eq, latticeEmbedLift_eval_eq]

/-- Actual finite covariance source: expected weighted energy outside any finite set. -/
theorem periodic5DRawAtomicLift_integral_tail_le
    (w : (Fin 5 → ℤ) → ℝ) (hw : Summable w) (hw0 : ∀ k, 0 ≤ w k)
    (K : Finset (Fin 5 → ℤ))
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) :
    (∫ ω, ∑' k : {k : Fin 5 → ℤ // k ∉ K},
      w k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
      finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) ≤
      (2 * (mass⁻¹ ^ 2 * L ^ 5)) * ∑' k : {k : Fin 5 → ℤ // k ∉ K}, w k := by
  let C := 2 * (mass⁻¹ ^ 2 * L ^ 5)
  have hs : Summable (fun k : {k : Fin 5 → ℤ // k ∉ K} => w k * C) :=
    (hw.subtype _).mul_right C
  have hi (k : {k : Fin 5 → ℤ // k ∉ K}) :=
    (periodic5DRawAtomicLift_integrable_sq N a mass L ha hmass hL k).const_mul (w k)
  have hb (k : {k : Fin 5 → ℤ // k ∉ K}) :
      ∫ ω, w k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
        finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass) ≤ w k * C := by
    rw [integral_const_mul]
    exact mul_le_mul_of_nonneg_left
      (periodic5DRawAtomicLift_integral_norm_sq_le N a mass L ha hmass hvol hL k) (hw0 k)
  have hn (k : {k : Fin 5 → ℤ // k ∉ K}) :
      0 ≤ ∫ ω, w k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 ∂
        finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass) :=
    integral_nonneg (fun ω => mul_nonneg (hw0 k) (sq_nonneg _))
  have ht := hs.of_nonneg_of_le hn hb
  have heq := integral_tsum_of_summable_integral_norm hi (by
    apply ht.congr
    intro k
    congr 1
    funext ω
    exact ((Real.norm_eq_abs _).trans (abs_of_nonneg (mul_nonneg (hw0 k) (sq_nonneg _)))).symm)
  rw [← heq]
  calc
    _ ≤ ∑' k : {k : Fin 5 → ℤ // k ∉ K}, w k * C := ht.tsum_le_tsum hb hs
    _ = _ := by rw [tsum_mul_right]; exact mul_comm _ _

end Pphi2Clean.Continuum
