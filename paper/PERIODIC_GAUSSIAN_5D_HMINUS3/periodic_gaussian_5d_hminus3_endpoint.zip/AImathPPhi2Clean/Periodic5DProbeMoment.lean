import AImathPPhi2Clean.PhysicalLatticeGaussianLaw
import AImathPPhi2Clean.RealFourierSecondMoment

noncomputable section
namespace Pphi2Clean.Continuum

open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice

def periodic5DComplexFourierProbe (L : ℝ) (hL : 0 < L)
    (k : (Fin 5 → ℤ))
    (ω : WeakDual ℝ (BoundedContinuousFunction (Fin 5 → ℝ) ℝ)) : ℂ :=
  (ω (periodicCosineTest 5 L k hL) : ℂ) +
    (ω (periodicSineTest 5 L k hL) : ℂ) * Complex.I

theorem periodic5DComplexFourierProbe_norm_sq (L : ℝ) (hL : 0 < L)
    (k : (Fin 5 → ℤ))
    (ω : WeakDual ℝ (BoundedContinuousFunction (Fin 5 → ℝ) ℝ)) :
    ‖periodic5DComplexFourierProbe L hL k ω‖ ^ 2 =
      (ω (periodicCosineTest 5 L k hL)) ^ 2 +
        (ω (periodicSineTest 5 L k hL)) ^ 2 := by
  unfold periodic5DComplexFourierProbe
  rw [Complex.sq_norm, Complex.normSq_add_mul_I]

def periodic5DComplexFourierProbeMoment (N : ℕ) [NeZero N]
    (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hL : 0 < L) (k : (Fin 5 → ℤ)) : ℝ :=
  ∫ ω, ‖periodic5DComplexFourierProbe L hL k ω‖ ^ 2 ∂
    physicalGJMeasure 5 N a mass ha hmass

theorem periodic5DComplexFourierProbeMoment_le (N : ℕ) [NeZero N]
    (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) (k : (Fin 5 → ℤ)) :
    periodic5DComplexFourierProbeMoment N a mass L ha hmass hL k ≤
      2 * (mass⁻¹ ^ 2 * L ^ 5) := by
  unfold periodic5DComplexFourierProbeMoment
  have hcosLaw := physicalGJMeasure_eval_hasGaussianLaw 5 N a mass ha hmass
    (periodicCosineTest 5 L k hL)
  have hsinLaw := physicalGJMeasure_eval_hasGaussianLaw 5 N a mass ha hmass
    (periodicSineTest 5 L k hL)
  have hcosInt : Integrable (fun ω => (ω (periodicCosineTest 5 L k hL)) ^ 2)
      (physicalGJMeasure 5 N a mass ha hmass) := hcosLaw.memLp_two.integrable_sq
  have hsinInt : Integrable (fun ω => (ω (periodicSineTest 5 L k hL)) ^ 2)
      (physicalGJMeasure 5 N a mass ha hmass) := hsinLaw.memLp_two.integrable_sq
  have hcos := physicalGJMeasure_periodicCosineTest_second_moment_le
    5 N a mass L ha hmass hvol k hL
  have hsin := physicalGJMeasure_periodicSineTest_second_moment_le
    5 N a mass L ha hmass hvol k hL
  calc
    (∫ ω, ‖periodic5DComplexFourierProbe L hL k ω‖ ^ 2
        ∂physicalGJMeasure 5 N a mass ha hmass) =
      ∫ ω, (ω (periodicCosineTest 5 L k hL)) ^ 2 +
        (ω (periodicSineTest 5 L k hL)) ^ 2
        ∂physicalGJMeasure 5 N a mass ha hmass := by
          apply integral_congr_ae
          filter_upwards [] with ω
          exact periodic5DComplexFourierProbe_norm_sq L hL k ω
    _ = (∫ ω, (ω (periodicCosineTest 5 L k hL)) ^ 2
          ∂physicalGJMeasure 5 N a mass ha hmass) +
        ∫ ω, (ω (periodicSineTest 5 L k hL)) ^ 2
          ∂physicalGJMeasure 5 N a mass ha hmass := integral_add hcosInt hsinInt
    _ ≤ mass⁻¹ ^ 2 * L ^ 5 + mass⁻¹ ^ 2 * L ^ 5 := add_le_add hcos hsin
    _ = 2 * (mass⁻¹ ^ 2 * L ^ 5) := by ring

theorem periodic5DComplexFourierProbeMoment_nonneg (N : ℕ) [NeZero N]
    (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hL : 0 < L) (k : (Fin 5 → ℤ)) :
    0 ≤ periodic5DComplexFourierProbeMoment N a mass L ha hmass hL k := by
  unfold periodic5DComplexFourierProbeMoment
  exact integral_nonneg (fun _ => sq_nonneg _)

end Pphi2Clean.Continuum
