import AImathPPhi2Clean.Periodic5DSobolevWeights
import AImathPPhi2Clean.FiniteFourierCoordinateConvergence

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Filter Topology
open Pphi2Clean.UpstreamLattice

def periodic5DFourierTestFamily {m : ℕ} (L : ℝ) (hL : 0 < L)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    Fin m → BoundedContinuousFunction (Fin 5 → ℝ) ℝ :=
  periodicFourierTestFamily 5 m L hL modes useSine

theorem periodic5DFourierTestFamily_covariance_tendsto
    {m : ℕ} (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) (i j : Fin m) :
    Filter.Tendsto
      (fixedVolumeCovarianceInner 5 L mass hL hmass
        (periodic5DFourierTestFamily L hL modes useSine i)
        (periodic5DFourierTestFamily L hL modes useSine j))
      Filter.atTop
      (nhds (periodicResolventCovarianceMatrix 5 m L mass hmass
        (periodic5DFourierTestFamily L hL modes useSine) i j)) := by
  change Filter.Tendsto
    (fixedVolumeCovarianceInner 5 L mass hL hmass
      (periodicFourierTestFamily 5 m L hL modes useSine i)
      (periodicFourierTestFamily 5 m L hL modes useSine j))
    Filter.atTop
    (nhds (periodicResolventCovarianceMatrix 5 m L mass hmass
      (periodicFourierTestFamily 5 m L hL modes useSine) i j))
  have hlim := fixedVolumeCovarianceInner_tendsto_periodicMassiveResolvent
    5 L mass hL hmass
    (periodicFourierTestFamily 5 m L hL modes useSine i)
    (periodicFourierTestFamily 5 m L hL modes useSine j)
    (periodicFourierTestFamily_isFlatTorusPeriodic 5 m L hL modes useSine i)
    (periodicFourierTestFamily_isFlatTorusPeriodic 5 m L hL modes useSine j)
  have hpair :
      (torusFourierGreenPairing 5 L mass
        (periodicFourierTestFamily 5 m L hL modes useSine i)
        (periodicFourierTestFamily 5 m L hL modes useSine j)).re =
      periodicResolventCovarianceMatrix 5 m L mass hmass
        (periodicFourierTestFamily 5 m L hL modes useSine) i j := by
    unfold periodicResolventCovarianceMatrix
    rw [← torusFourierGreenPairing_eq_physicalTorusResolventPairing 5 L mass hL hmass]
  have hphysical :
      (physicalTorusResolventPairing 5 L mass hmass
        (periodicFourierTestFamily 5 m L hL modes useSine i)
        (periodicFourierTestFamily 5 m L hL modes useSine j)).re =
      periodicResolventCovarianceMatrix 5 m L mass hmass
        (periodicFourierTestFamily 5 m L hL modes useSine) i j := by
    rw [← torusFourierGreenPairing_eq_physicalTorusResolventPairing 5 L mass hL hmass]
    exact hpair
  rw [← hphysical]
  exact hlim

theorem periodic5DFourierTestFamily_finiteMeasure_tendsto
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    Filter.Tendsto
      (fun n : ℕ => let N := n + 1; letI : NeZero N := ⟨Nat.succ_ne_zero n⟩
        physicalFamilyEvalProbabilityMeasure 5 N m (L / (N : ℝ)) mass
          (div_pos hL (Nat.cast_pos.mpr (Nat.succ_pos n))) hmass
          (periodic5DFourierTestFamily L hL modes useSine))
      Filter.atTop
      (nhds (periodicResolventTargetProbabilityMeasure 5 m L mass hmass
        (periodic5DFourierTestFamily L hL modes useSine))) := by
  simpa [periodic5DFourierTestFamily] using
    physicalPeriodicFourierFamilyProbabilityMeasure_fixedVolume_tendsto
      5 m L mass hL hmass modes useSine

end Pphi2Clean.Continuum
