import AImathPPhi2Clean.Periodic5DEnergy
import AImathPPhi2Clean.Periodic5DCompactEmbedding
import AImathPPhi2Clean.Periodic5DFiniteSourceLift
import Mathlib.MeasureTheory.Measure.Prokhorov

set_option maxHeartbeats 2000000
noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory Pphi2Clean.UpstreamLattice

theorem periodic5DFiniteSourceFourierLift_integrable_norm_sq
    (s : ℝ) (hs : Summable (periodic5DSobolevWeight s))
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass) :
    Integrable (fun ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)) =>
      ‖periodic5DFiniteSourceFourierLift s hs N a L ω‖ ^ 2)
      (finiteCovarianceGaussianMeasure
        (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) := by
  let T := numberedLatticeCovarianceGJ 5 N a mass ha hmass
  let μ := finiteCovarianceGaussianMeasure T
  have hcoord (j : Fin (Fintype.card (FinLatticeSites 5 N))) :
      MemLp (fun ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)) =>
        ω (Pi.single j (1 : ℝ) : FiniteLatticeField
          (Fintype.card (FinLatticeSites 5 N)))) 2 μ := by
    have hg := finiteCovarianceGaussianMeasure_eval_hasGaussianLaw T
      (Pi.single j (1 : ℝ))
    exact hg.memLp_two
  have hsum : MemLp (fun ω : FiniteLatticeConfiguration
      (Fintype.card (FinLatticeSites 5 N)) =>
      ∑ j : Fin (Fintype.card (FinLatticeSites 5 N)),
        (ω (Pi.single j (1 : ℝ) : FiniteLatticeField
          (Fintype.card (FinLatticeSites 5 N))) : ℝ) •
          periodic5DSiteVector s hs N a L j) 2 μ := by
    have hsum' : MemLp (∑ j ∈ (Finset.univ : Finset
        (Fin (Fintype.card (FinLatticeSites 5 N)))),
        fun ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)) =>
          (ω (Pi.single j (1 : ℝ) : FiniteLatticeField
            (Fintype.card (FinLatticeSites 5 N))) : ℝ) •
            periodic5DSiteVector s hs N a L j) 2 μ := by
      apply MeasureTheory.memLp_finsetSum'
      intro j hj
      have hconst : MemLp (fun _ : FiniteLatticeConfiguration
          (Fintype.card (FinLatticeSites 5 N)) =>
            periodic5DSiteVector s hs N a L j) ⊤ μ := memLp_const _
      exact hconst.smul (hcoord j)
    convert hsum' using 1
    ext ω
    simp [Finset.sum_apply]
  change Integrable (fun ω : FiniteLatticeConfiguration
    (Fintype.card (FinLatticeSites 5 N)) =>
      ‖periodic5DFiniteSourceFourierLift s hs N a L ω‖ ^ 2) μ
  have hmap : MemLp (periodic5DFiniteSourceFourierLift s hs N a L) 2 μ := by
    change MemLp (fun ω => periodic5DFiniteSourceCoefficientMap s hs N a L
      (fun j => ω (Pi.single j (1 : ℝ) : FiniteLatticeField
        (Fintype.card (FinLatticeSites 5 N)))) ) 2 μ
    unfold periodic5DFiniteSourceCoefficientMap
    convert hsum using 1
  exact hmap.integrable_norm_pow'


theorem periodic5DFiniteSourceFourierLift_norm_sq (s : ℝ) (hs : Summable (periodic5DSobolevWeight s)) (N : ℕ) [NeZero N]
    (a L : ℝ) (ha : 0 < a) (hL : 0 < L)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N))) :
    ‖periodic5DFiniteSourceFourierLift s hs N a L ω‖ ^ 2 =
      ∑' k : Periodic5DIndex, periodic5DSobolevWeight s k *
        ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 := by
  have hnorm := lp.norm_rpow_eq_tsum (by norm_num : 0 < (2 : ENNReal).toReal)
    (periodic5DFiniteSourceFourierLift s hs N a L ω)
  norm_num at hnorm
  rw [hnorm]
  apply tsum_congr
  intro k
  have hraw := congrFun
    (periodic5DRawWeightedLift_eq_finiteSourceFourierLift s hs N a L ha hL ω) k
  rw [← hraw, norm_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (Real.sqrt_nonneg _), mul_pow]
  change (Real.sqrt (periodic5DSobolevWeight s k)) ^ 2 *
      ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2 =
      periodic5DSobolevWeight s k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2
  rw [Real.sq_sqrt (periodic5DSobolevWeight_nonneg s k)]


theorem periodic5DFiniteSourceFourierLiftElevenQuarters_integral_norm_sq_le
    (N : ℕ) [NeZero N] (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) :
    (∫ ω, ‖periodic5DFiniteSourceFourierLift (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L ω‖ ^ 2
      ∂finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)) ≤
      2 * (mass⁻¹ ^ 2 * L ^ 5) * ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k := by
  simp_rw [periodic5DFiniteSourceFourierLift_norm_sq (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L ha hL]
  exact periodic5DRawAtomicLift_integral_energy_eleven_quarters_le N a mass L ha hmass hvol hL

def periodic5DFiniteSourceGaussianMeasure (N : ℕ) [NeZero N]
    (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass) : Measure Periodic5DCompletion :=
  Measure.map (periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L)
    (finiteCovarianceGaussianMeasure
      (numberedLatticeCovarianceGJ 5 N a mass ha hmass))

instance periodic5DFiniteSourceGaussianMeasure_isProbability (N : ℕ) [NeZero N]
    (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass) :
    IsProbabilityMeasure (periodic5DFiniteSourceGaussianMeasure N a mass L ha hmass) := by
  unfold periodic5DFiniteSourceGaussianMeasure
  exact (Measure.isProbabilityMeasure_map_iff
    (measurable_periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L).aemeasurable).2 inferInstance

theorem periodic5DFiniteSourceGaussianMeasure_apply (N : ℕ) [NeZero N]
    (a mass L : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (s : Set Periodic5DCompletion) (hs : MeasurableSet s) :
    periodic5DFiniteSourceGaussianMeasure N a mass L ha hmass s =
      finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)
        ((periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L) ⁻¹' s) := by
  rw [periodic5DFiniteSourceGaussianMeasure]
  exact Measure.map_apply
    (measurable_periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L) hs

def periodic5DFixedVolumeProbabilityMeasure
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) (n : ℕ) :
    ProbabilityMeasure Periodic5DCompletion := by
  let N := n + 1
  let a : ℝ := L / ((n + 1 : ℕ) : ℝ)
  have ha : 0 < a := by
    dsimp [a]
    exact div_pos hL (Nat.cast_pos.mpr (Nat.succ_pos n))
  have hNa : a * (N : ℝ) = L := by
    dsimp [a, N]
    field_simp
  exact ⟨periodic5DFiniteSourceGaussianMeasure N a mass L ha hmass,
    inferInstance⟩

theorem periodic5DFiniteSourceFourierLiftElevenQuarters_markov_tail
    (N : ℕ) [NeZero N] (a mass L B : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) (hB : 0 < B) :
    finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)
      {ω | B ^ 2 ≤ ‖periodic5DFiniteSourceFourierLift (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L ω‖ ^ 2} ≤
      ENNReal.ofReal ((2 * (mass⁻¹ ^ 2 * L ^ 5) *
        ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k) / B ^ 2) := by
  let μ := finiteCovarianceGaussianMeasure
    (numberedLatticeCovarianceGJ 5 N a mass ha hmass)
  let X := periodic5DFiniteSourceFourierLift (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L
  have hInt := periodic5DFiniteSourceFourierLift_integrable_norm_sq (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a mass L ha hmass
  have hSecond := periodic5DFiniteSourceFourierLiftElevenQuarters_integral_norm_sq_le
    N a mass L ha hmass hvol hL
  have hScaled : Integrable (fun ω => ‖X ω‖ ^ 2 / B ^ 2) μ := by
    have hmul := hInt.const_mul ((B ^ 2)⁻¹)
    convert hmul using 1
    ext ω
    simp [X, div_eq_mul_inv, mul_comm]
  have hNonneg : 0 ≤ᵐ[μ] (fun ω => ‖X ω‖ ^ 2 / B ^ 2) := by
    filter_upwards [] with ω
    exact div_nonneg (sq_nonneg ‖X ω‖) (sq_nonneg B)
  let s : Set (FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N))) :=
    {ω | B ^ 2 ≤ ‖X ω‖ ^ 2}
  have hMarkov := hScaled.measure_le_integral hNonneg (s := s)
    (by
      intro ω hω
      dsimp [s] at hω ⊢
      exact (le_div_iff₀ (sq_pos_of_pos hB)).2 (by simpa using hω))
  have hIntegral : (∫ ω, ‖X ω‖ ^ 2 / B ^ 2 ∂μ) ≤
      (2 * (mass⁻¹ ^ 2 * L ^ 5) * ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k) / B ^ 2 := by
    have hscale : (∫ ω, ‖X ω‖ ^ 2 / B ^ 2 ∂μ) =
        (B ^ 2)⁻¹ * ∫ ω, ‖X ω‖ ^ 2 ∂μ := by
      rw [show (fun ω => ‖X ω‖ ^ 2 / B ^ 2) =
        (fun ω => (B ^ 2)⁻¹ * ‖X ω‖ ^ 2) by
          funext ω
          ring]
      rw [integral_const_mul]
    rw [hscale]
    calc
      (B ^ 2)⁻¹ * ∫ ω, ‖X ω‖ ^ 2 ∂μ ≤
          (B ^ 2)⁻¹ * ((2 * (mass⁻¹ ^ 2 * L ^ 5)) *
            ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k) :=
        mul_le_mul_of_nonneg_left hSecond (inv_nonneg.mpr (sq_nonneg B))
      _ = (2 * (mass⁻¹ ^ 2 * L ^ 5) *
          ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k) / B ^ 2 := by ring
  have hOfReal := ENNReal.ofReal_le_ofReal hIntegral
  change μ s ≤ _ at hMarkov
  rw [show μ = finiteCovarianceGaussianMeasure
    (numberedLatticeCovarianceGJ 5 N a mass ha hmass) by rfl] at hMarkov
  exact hMarkov.trans hOfReal



theorem periodic5DRawAtomicLift_mem_carrier (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s)) (N : ℕ) [NeZero N]
    (a L : ℝ) (ha : 0 < a) (hL : 0 < L)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N))) :
    periodic5DRawAtomicLift N a L hL ω ∈ periodic5DCarrier s := by
  have hm := lp.memℓp (periodic5DFiniteSourceFourierLift s hs N a L ω)
  rw [memℓp_gen_iff (by norm_num : 0 < (2 : ENNReal).toReal)] at hm
  change Summable (fun k => periodic5DSobolevWeight s k * ‖periodic5DRawAtomicLift N a L hL ω k‖ ^ 2)
  apply hm.congr
  intro k
  have hr := congrFun (periodic5DRawWeightedLift_eq_finiteSourceFourierLift s hs N a L ha hL ω) k
  rw [← hr]
  simp only [ENNReal.toReal_ofNat, Real.rpow_two, norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _), mul_pow, Real.sq_sqrt (periodic5DSobolevWeight_nonneg s k)]

theorem periodic5DFiniteSourceFourierLift_norm_eq_raw (s : ℝ)
    (hs : Summable (periodic5DSobolevWeight s)) (N : ℕ) [NeZero N]
    (a L : ℝ) (ha : 0 < a) (hL : 0 < L)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N))) :
    ‖periodic5DFiniteSourceFourierLift s hs N a L ω‖ = periodic5DCarrierNorm s (periodic5DRawAtomicLift N a L hL ω) := by
  rw [← Real.sqrt_sq (norm_nonneg _), periodic5DFiniteSourceFourierLift_norm_sq s hs N a L ha hL]
  rfl

theorem periodic5DFiniteSourceFourierLift_mem_eleven_quarters_ball
    (N : ℕ) [NeZero N] (a L B : ℝ) (ha : 0 < a) (hL : 0 < L)
    (ω : FiniteLatticeConfiguration (Fintype.card (FinLatticeSites 5 N)))
    (hB : ‖periodic5DFiniteSourceFourierLift (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L ω‖ ≤ B) :
    periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L ω ∈ periodic5DElevenQuartersBallInHminusThree B := by
  refine ⟨periodic5DRawAtomicLift N a L hL ω, periodic5DRawAtomicLift_mem_carrier (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L ha hL ω, ?_, ?_⟩
  · change periodic5DCarrierNorm (11/4) (periodic5DRawAtomicLift N a L hL ω) ≤ B
    rw [← periodic5DFiniteSourceFourierLift_norm_eq_raw (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L ha hL ω]
    exact hB
  · apply lp.ext
    funext k
    exact (congrFun (periodic5DRawWeightedLift_eq_finiteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L ha hL ω) k).symm

theorem periodic5DFiniteSourceGaussianMeasure_compactTail
    (N : ℕ) [NeZero N] (a mass L B : ℝ) (ha : 0 < a) (hmass : 0 < mass)
    (hvol : a * (N : ℝ) = L) (hL : 0 < L) (hB : 0 < B) :
    periodic5DFiniteSourceGaussianMeasure N a mass L ha hmass
      (closure (periodic5DElevenQuartersBallInHminusThree B))ᶜ ≤
      ENNReal.ofReal ((2 * (mass⁻¹ ^ 2 * L ^ 5) *
        ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k) / B ^ 2) := by
  let μ := finiteCovarianceGaussianMeasure (numberedLatticeCovarianceGJ 5 N a mass ha hmass)
  let X := periodic5DFiniteSourceFourierLift (11/4) periodic5DSobolevWeight_eleven_quarters_summable N a L
  let Y := periodic5DFiniteSourceFourierLift 3 periodic5DHminusThreeWeight_summable N a L
  let K : Set Periodic5DCompletion := closure (periodic5DElevenQuartersBallInHminusThree B)
  have hKcompact : IsCompact K := isCompact_closure_periodic5DElevenQuartersBall B hB.le
  have hpre : Y ⁻¹' Kᶜ ⊆ {ω | B ^ 2 ≤ ‖X ω‖ ^ 2} := by
    intro ω hω
    by_contra htail
    have hnorm : ‖X ω‖ ≤ B := by
      have hh : ‖X ω‖ ^ 2 < B ^ 2 := lt_of_not_ge htail
      nlinarith [norm_nonneg (X ω)]
    exact hω (subset_closure
      (periodic5DFiniteSourceFourierLift_mem_eleven_quarters_ball N a L B ha hL ω hnorm))
  rw [periodic5DFiniteSourceGaussianMeasure_apply N a mass L ha hmass Kᶜ
    hKcompact.isClosed.measurableSet.compl]
  exact (measure_mono hpre).trans
    (periodic5DFiniteSourceFourierLiftElevenQuarters_markov_tail N a mass L B ha hmass hvol hL hB)

theorem periodic5DFixedVolumeProbabilityMeasureSet_tight
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass) :
    IsTightMeasureSet
      {ρ : Measure Periodic5DCompletion |
        ∃ n, ρ = (periodic5DFixedVolumeProbabilityMeasure L mass hL hmass n : Measure _) } := by
  refine (isTightMeasureSet_iff_exists_isCompact_measure_compl_le).2 ?_
  intro ε hε
  by_cases htop : ε = ⊤
  · refine ⟨∅, isCompact_empty, ?_⟩
    intro ρ hρ
    simp [htop]
  · have hεreal : 0 < ε.toReal := ENNReal.toReal_pos hε.ne' htop
    let er : ℝ := ε.toReal
    let C : ℝ := 2 * (mass⁻¹ ^ 2 * L ^ 5) *
      ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k
    let D : ℝ := C + 1
    let B : ℝ := Real.sqrt (D / er)
    have hsum : 0 ≤ ∑' k : Periodic5DIndex, periodic5DSobolevWeight (11/4) k :=
      tsum_nonneg (fun k => periodic5DSobolevWeight_nonneg (11/4) k)
    have hC : 0 ≤ C := by
      dsimp [C]
      positivity
    have hD : 0 < D := by dsimp [D]; linarith
    have her : 0 < er := hεreal
    have hB : 0 < B := by
      dsimp [B]
      exact Real.sqrt_pos.2 (div_pos hD her)
    refine ⟨closure (periodic5DElevenQuartersBallInHminusThree B),
      isCompact_closure_periodic5DElevenQuartersBall B hB.le, ?_⟩
    intro ρ hρ
    rcases hρ with ⟨n, rfl⟩
    dsimp [periodic5DFixedVolumeProbabilityMeasure]
    let N := n + 1
    let a : ℝ := L / ((n + 1 : ℕ) : ℝ)
    have ha : 0 < a := by
      dsimp [a]
      exact div_pos hL (Nat.cast_pos.mpr (Nat.succ_pos n))
    have hNa : a * (N : ℝ) = L := by
      dsimp [a, N]
      field_simp
    have htail := periodic5DFiniteSourceGaussianMeasure_compactTail
      N a mass L B ha hmass hNa hL hB
    rw [← ENNReal.ofReal_toReal htop]
    have hBsq : B ^ 2 = D / er := by
      dsimp [B]
      rw [Real.sq_sqrt (le_of_lt (div_pos hD her))]
    have hreal : C / B ^ 2 ≤ er := by
      rw [hBsq]
      dsimp [D]
      have her0 : 0 ≤ er := her.le
      have hden : 0 < C + 1 := by linarith
      apply (div_le_iff₀ (div_pos (by linarith : 0 < C + 1) her)).2
      field_simp
      nlinarith
    exact htail.trans (ENNReal.ofReal_le_ofReal hreal)
open Filter
open scoped Topology
theorem periodic5DFixedVolume_prokhorov_subsequence
    (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (ns : ℕ → ℕ) (_hns : Tendsto ns atTop atTop) :
    ∃ (ms : ℕ → ℕ) (ν : ProbabilityMeasure Periodic5DCompletion),
      StrictMono ms ∧
      Tendsto
        (fun k => periodic5DFixedVolumeProbabilityMeasure L mass hL hmass (ns (ms k)))
        atTop (𝓝 ν) := by
  letI : TopologicalSpace.SeparableSpace Periodic5DCompletion :=
    periodic5DCompletion_separable
  let μ : ℕ → ProbabilityMeasure Periodic5DCompletion :=
    periodic5DFixedVolumeProbabilityMeasure L mass hL hmass
  let S : Set (ProbabilityMeasure Periodic5DCompletion) := Set.range μ
  have htight : IsTightMeasureSet
      {ρ : Measure Periodic5DCompletion | ∃ n, ρ = (μ n : Measure _)} := by
    simpa [μ] using periodic5DFixedVolumeProbabilityMeasureSet_tight L mass hL hmass
  have hcompact : IsCompact (closure S) := by
    apply isCompact_closure_of_isTightMeasureSet
    simpa [S, Set.ext_iff, eq_comm] using htight
  have hseq : ∀ n, μ (ns n) ∈ closure S := by
    intro n
    exact subset_closure ⟨ns n, rfl⟩
  obtain ⟨ν, _hνS, ms, hms, hlim⟩ := hcompact.tendsto_subseq hseq
  refine ⟨ms, ν, hms, ?_⟩
  simpa [Function.comp_def, μ] using hlim

end Pphi2Clean.Continuum
