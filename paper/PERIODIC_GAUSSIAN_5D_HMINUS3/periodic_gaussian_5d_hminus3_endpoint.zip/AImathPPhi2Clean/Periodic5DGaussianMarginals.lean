import AImathPPhi2Clean.Periodic5DGaussianTarget

noncomputable section
namespace Pphi2Clean.Continuum
open MeasureTheory ProbabilityTheory

theorem periodic5DGaussianTarget_fourierFamily_measure
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    ((periodic5DGaussianTarget L mass hL hmass : ProbabilityMeasure Periodic5DCompletion) : Measure _).map
      (periodic5DFourierFamilyProjection L hL modes useSine) =
      periodicResolventTargetMeasure 5 m L mass hmass
        (periodic5DFourierTestFamily L hL modes useSine) := by
  have h := congrArg (fun ρ : ProbabilityMeasure (EuclideanSpace ℝ (Fin m)) => (ρ : Measure (EuclideanSpace ℝ (Fin m))))
    (periodic5DGaussianTarget_fourierFamily_law m L mass hL hmass modes useSine)
  rw [ProbabilityMeasure.toMeasure_map] at h
  exact h

theorem periodic5DGaussianTarget_fourierFamily_hasGaussianLaw
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool) :
    HasGaussianLaw id (((periodic5DGaussianTarget L mass hL hmass : ProbabilityMeasure Periodic5DCompletion) : Measure _).map
      (periodic5DFourierFamilyProjection L hL modes useSine)) := by
  rw [periodic5DGaussianTarget_fourierFamily_measure]
  exact periodicResolventTargetMeasure_hasGaussianLaw 5 m L mass hmass _

theorem periodic5DGaussianTarget_fourierFamily_mean_zero
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool)
    (t : EuclideanSpace ℝ (Fin m)) :
    ∫ z, inner ℝ t z ∂(((periodic5DGaussianTarget L mass hL hmass : ProbabilityMeasure Periodic5DCompletion) : Measure _).map
      (periodic5DFourierFamilyProjection L hL modes useSine)) = 0 := by
  rw [periodic5DGaussianTarget_fourierFamily_measure]
  exact periodicResolventTargetMeasure_mean_zero 5 m L mass hmass _ t

theorem periodic5DGaussianTarget_fourierFamily_covariance_quadratic
    (m : ℕ) (L mass : ℝ) (hL : 0 < L) (hmass : 0 < mass)
    (modes : Fin m → Periodic5DIndex) (useSine : Fin m → Bool)
    (t : EuclideanSpace ℝ (Fin m)) :
    Var[fun z => inner ℝ t z; (((periodic5DGaussianTarget L mass hL hmass : ProbabilityMeasure Periodic5DCompletion) : Measure _).map
      (periodic5DFourierFamilyProjection L hL modes useSine))] =
      ∑ i : Fin m, ∑ j : Fin m, t i * t j *
        periodicResolventCovarianceMatrix 5 m L mass hmass
          (periodic5DFourierTestFamily L hL modes useSine) i j := by
  rw [periodic5DGaussianTarget_fourierFamily_measure]
  exact periodicResolventTargetMeasure_covariance_quadratic 5 m L mass hL hmass _ t

end Pphi2Clean.Continuum
