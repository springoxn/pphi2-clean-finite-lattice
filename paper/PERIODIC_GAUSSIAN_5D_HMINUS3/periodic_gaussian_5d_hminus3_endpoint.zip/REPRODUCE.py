from pathlib import Path
import hashlib, json, subprocess
root = Path(__file__).resolve().parent
for name, digest in json.loads((root/'SOURCE_HASHES.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
for command in [['lake','build','AImathPPhi2Clean.Periodic5DGaussianMarginals'],['lake','env','lean','Audit5D.lean']]:
    subprocess.run(command,cwd=root,check=True)
print('Source integrity, endpoint build, and typed axiom contract passed.')
